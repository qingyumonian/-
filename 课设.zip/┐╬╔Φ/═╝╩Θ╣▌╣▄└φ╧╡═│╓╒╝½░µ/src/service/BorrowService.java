package service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import Vo.Book;
import Vo.Borrow;
import Vo.Btype;
import Vo.Reader;
import dao.BookDao;
import dao.BorrowDao;
import dao.BtypeDao;
import dao.ReaderDao;

public class BorrowService {
	private BorrowDao borrowdao = new BorrowDao();
	private BookDao bookdao = new BookDao();
	private BtypeDao btypedao = new BtypeDao();
	private RtypeService rtypeservice = new RtypeService();
	private ReaderDao readerdao = new ReaderDao();

	public BorrowService() {
		// TODO Auto-generated constructor stub
	}
	public ArrayList<Borrow> queryBorrow() {
		ArrayList<Borrow> borrow = borrowdao.queryAllData();
		return borrow;
	}
	/*
	 * String bnumber, String bname, String author, String publish, Double price,
	 * Integer amount, String sjnumber, Date rkdate, String lnumber
	 */
	public int addBorrow(String jsnumber, String bnumber) {
		ArrayList<Book> m = bookdao.queryAllData();
		Iterator<Book> iterator = m.iterator();
		int flag = 0;
		int flag1 = 0;
		if (panDuanJieGuo(jsnumber, bnumber) == false){// �ж��Ƿ�������
			return -3;
		}
		if (panDuanShu(jsnumber) == false)// �жϽ��������Ƿ񳬳����Ľ�������
			return -2;
		if (panDuan(jsnumber) == false)// �ж��Ƿ�������δ�����鼮
			return -1;
		if (kuCun(bnumber) == false){ // �жϿ���Ƿ�
		
			return 2;
		}
		String lnumber = null;
		int day = 0;
		while (iterator.hasNext()) {//������    �����ܽ������
			Book n = new Book();
			n = iterator.next();
			if (n.getBnumber().equals(bnumber)) {
				flag = 1;
				lnumber = n.getLnumber();
				break;
			}
		}
		ArrayList<Btype> n = btypedao.queryAllData();
		Iterator<Btype> iterator_1 = n.iterator();
		while (iterator_1.hasNext()) {
			Btype t = new Btype();
			t = iterator_1.next();
			if (t.getLnumber().equals(lnumber)) {
				flag1 = 1;
				day = t.getKjday();

			}

		}
		if (flag == 1 && flag1 == 1) {
			Calendar canlendar = Calendar.getInstance(); // ��ȡϵͳʱ������
			java.util.Date date = canlendar.getTime(); // ����ʱ��util��ʱ��
			canlendar.setTime(date); // ��canlender��ֵ
			canlendar.add(Calendar.DATE, day); // ʱ�����ӿɽ�����
			java.util.Date date1 = canlendar.getTime(); // Ӧ���黹ʱ��util��
			java.sql.Date sTime = new java.sql.Date(date.getTime()); // ����ʱ��ת��
			java.sql.Date sqlDate = new java.sql.Date(date1.getTime());// Ӧ���黹ʱ��ת��
			Borrow borrow = new Borrow(jsnumber, bnumber, sTime, sqlDate);
			if (borrowdao.addBorrow(borrow) && bookdao.updataBookReduceShu(bnumber))
				return 1;
		}
		return 0;

	}

	public boolean delBorrow(String jsnumber, String bnumber) {
		ArrayList<Borrow> m = queryBorrow();
		Iterator<Borrow> iterator = m.iterator();
		int flag = 0;
		while (iterator.hasNext()) {
			Borrow n = new Borrow();
			n = iterator.next();
			if (n.getBnumber().equals(bnumber) && n.getJsnumber().equals(jsnumber)) {

				if (borrowdao.delBorrow(jsnumber, bnumber)) {
					flag = 1;
				}
				break;
			}

		}
		if (flag == 1)
			return true;
		else
			return false;
	}
	
	public Borrow findBorrow(String jsnumber, String bnumber) {
		Borrow borrow = borrowdao.findBorrow(jsnumber, bnumber);
		return borrow;
	}

	public ArrayList<Borrow> borrowList(String jsnumber) {

		ArrayList<Borrow> m = queryBorrow();
		ArrayList<Borrow> borrow = new ArrayList<Borrow>();
		Iterator<Borrow> iterator = m.iterator();
		while (iterator.hasNext()) {
			Borrow n = new Borrow();
			n = iterator.next();
			if (n.getJsnumber().equals(jsnumber)) {
				borrow.add(n);
			}

		}
		return borrow;
	}

	public int returnBook(String jsnumber, String bnumber) {
		ArrayList<Borrow> m = queryBorrow();
		Iterator<Borrow> iterator = m.iterator();
		int flag = 0;
		while (iterator.hasNext()) {
			Borrow n = new Borrow();
			n = iterator.next();
			if (n.getBnumber().equals(bnumber) && n.getJsnumber().equals(jsnumber)) {
				boolean delSuccess = borrowdao.delBorrow(n.getJsnumber(), n.getBnumber());
				boolean addBook = bookdao.updataBookAddShu(n.getBnumber());
				if (delSuccess && addBook) {
					flag = 1;
				}
				break;
			}

		}
		return flag;

	}

	public boolean panDuan(String jsnumber) { // �ж��Ƿ�������δ�����鼮
		ArrayList<Borrow> m = queryBorrow();
		Iterator<Borrow> iterator = m.iterator();
		int flag = 0;
		while (iterator.hasNext()) {
			Borrow t = new Borrow();
			t = iterator.next();
			if (t.getJsnumber().equals(jsnumber)) {
				Calendar canlendar = Calendar.getInstance(); // ��ȡϵͳʱ������
				java.util.Date date = canlendar.getTime(); // ����ʱ��util��ʱ��
				canlendar.setTime(date); // ��canlender��ֵ
				Calendar canlendarNew = Calendar.getInstance();
				canlendarNew.setTime(t.getReturndate());
				if (canlendar.compareTo(canlendarNew) >= 0) {// ϵͳʱ��͹黹ʱ��Ƚ�
					flag = 1;
					break;
				}
			}
		}
		if (flag == 1)
			return false;
		else
			return true;
	}

	public boolean panDuanShu(String jsnumber) { // �жϽ��������Ƿ񳬳����Ľ�������
		ArrayList<Borrow> m = borrowList(jsnumber);
		int n = m.size(); // �ѽ�����
		ArrayList<Reader> t = readerdao.queryAllData();
		Iterator<Reader> iterator = t.iterator();
		int flag = 0;
		while (iterator.hasNext()) {
			Reader q = new Reader();
			q = iterator.next();
			if (q.getJsnumber().equals(jsnumber)) {
				int shu = rtypeservice.findRtypeShu(q.getLxnumber());
				if (shu < n) {
					flag = 1;
					break;
				}

			}
		}
		if (flag == 0)
			return true;
		else
			return false;
	}

	public boolean panDuanJieGuo(String jsnumber, String bnumber) { // �ж϶����Ƿ����Ȿ��

		ArrayList<Borrow> m = queryBorrow();
		Iterator<Borrow> iterator = m.iterator();
		int flag = 0;
		while (iterator.hasNext()) {
			Borrow t = new Borrow();
			t = iterator.next();
			if (t.getJsnumber().equals(jsnumber) && t.getBnumber().equals(bnumber)) {
				flag = 1;
				break;
			}
		}
		if (flag == 1)
			return false;
		else
			return true;
	}

	public boolean kuCun(String bnumber) { // �жϿ���Ƿ�
		ArrayList<Book> m = bookdao.queryAllData();
		Iterator<Book> iterator = m.iterator();
		int flag = 0;
		while (iterator.hasNext()) {
			Book t = new Book();
			t = iterator.next();
			if (t.getBnumber().equals(bnumber)) {
				if (t.getAmount() >= 1) {
					flag = 1;
					break;
				}

			}
		}
		if (flag == 0)
			return false;
		else
			return true;
	}
	public boolean panDuanBorrow(String jsnumber) { // �ж϶����н��ļ�¼

		ArrayList<Borrow> m = queryBorrow();
		Iterator<Borrow> iterator = m.iterator();
		int flag = 0;
		while (iterator.hasNext()) {
			Borrow t = new Borrow();
			t = iterator.next();
			if (t.getJsnumber().equals(jsnumber)) {
				flag = 1;
				break;
			}
		}
		if (flag == 1)
			return true;
		else
			return false;
	}

}
