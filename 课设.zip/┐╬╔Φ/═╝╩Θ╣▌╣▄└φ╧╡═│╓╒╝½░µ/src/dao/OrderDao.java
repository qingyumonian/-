package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import Vo.Order;
import dbc.JDBCUtils;

/**
 * ͼ�鶩��Dao�� �� ɾ ��
 *
 */
public class OrderDao {

	public ArrayList<Order> queryAllData(){
		Connection conn=null;
		Statement  stmt=null;
		ResultSet rs=null;
		ArrayList<Order> order=new ArrayList<Order>();
		try {
			conn=JDBCUtils.getConnection(1);
			stmt=conn.createStatement();
			String sql="select tnumber,tname,author,publish,price,dgdate,dgquantity,administer,checkout from Orders";
			rs=stmt.executeQuery(sql);
			while(rs.next()) {
				Order m=new Order();
				m.setTnumber(rs.getString("tnumber"));
				m.setTname(rs.getString("tname"));
				m.setAuthor(rs.getString("author"));
				m.setPublish(rs.getString("publish"));
				m.setPrice(rs.getDouble("price"));
				m.setDgdate(rs.getDate("dgdate"));
				m.setDgquantity(rs.getInt("dgquantity"));
				m.setAdminister(rs.getString("administer"));
				m.setCheckout(rs.getString("checkout"));
				order.add(m);
			}
/*String tnumber, String tname, String author, String publish, Double price, Date dgdate,
			Integer dgquantity, String administer, Boolean checkout*/
		return order;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return null;
	}
	public boolean addOrder(Order m) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try {
			conn=JDBCUtils.getConnection(1);
			String sql="insert into Orders (tnumber,tname,author,publish,price,dgdate,dgquantity,administer,checkout) values (?,?,?,?,?,?,?,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, m.getTnumber());
			pstmt.setString(2, m.getTname());
			pstmt.setString(3, m.getAuthor());
			pstmt.setString(4, m.getPublish());
			pstmt.setDouble(5, m.getPrice());
			pstmt.setDate(6, m.getDgdate());
			pstmt.setInt(7, m.getDgquantity());
			pstmt.setString(8, m.getAdminister());
			pstmt.setString(9, m.getCheckout());
			if(pstmt.executeUpdate()>0)
			{
				result=true;
			}
/*String tnumber, String tname, String author, String publish, Double price, Date dgdate,
			Integer dgquantity, String administer, Boolean checkout*/		
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
public boolean delOrder(String tnumber) {
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try{
			conn=JDBCUtils.getConnection(1);
			String  sql="delete from Orders where tnumber = ?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, tnumber);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	
	
}
