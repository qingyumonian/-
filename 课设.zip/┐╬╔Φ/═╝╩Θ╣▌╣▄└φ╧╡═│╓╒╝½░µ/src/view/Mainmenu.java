package view;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import tools.GUITools;

import javax.swing.JMenu;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;


public class Mainmenu {      //���˵�

	JFrame frame;
	private JMenu useradmin;
	private JMenuItem addreader;
	private JMenuItem delupreader;
	private JMenuItem findereader;
	private JMenu bookadmin;
	private JMenu booktype;
	private JMenuItem addtype;
	private JMenuItem updatatype;
	private JMenu bookxinxi;
	private JMenuItem addbook;
	private JMenuItem delbook;
	private JMenu borrowadmin;
	private JMenuItem borrowbook;
	private JMenuItem returnbook;
	private JMenuItem findborrow;
	private JMenuBar menuBar;
	private JMenu ding;
	private JMenuItem menuItem;
	private JMenuItem menuItem_1;
	private JMenuItem menuItem_3;
	private JMenuItem menuItem_4;
	private JMenuItem menuItem_2;
	private JMenu menu;
	private JMenuItem menuItem_5;
	private JLabel label;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public Mainmenu() {
		initialize();
		addListener();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0, 600, 400);
		frame.setTitle("��ҳ�˵�");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"32.png");//����ͼ��
		menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		useradmin = new JMenu("������Ϣ����");
		menuBar.add(useradmin);
		
		addreader = new JMenuItem("������Ϣ����");
		
		useradmin.add(addreader);
		
		delupreader = new JMenuItem("������Ϣ�޸���ɾ��");
		
		useradmin.add(delupreader);
		
		findereader = new JMenuItem("������Ϣ����");
		
		useradmin.add(findereader);
		
		bookadmin = new JMenu("ͼ����Ϣ����");
		menuBar.add(bookadmin);
		
		booktype = new JMenu("������");
		bookadmin.add(booktype);
		
		addtype = new JMenuItem("ͼ���������");
		
		booktype.add(addtype);
		
		updatatype = new JMenuItem("ͼ������޸�");
		
		booktype.add(updatatype);
		
		bookxinxi = new JMenu("��Ϣ����");
		bookadmin.add(bookxinxi);
		
		addbook = new JMenuItem("ͼ����Ϣ����");
		
		bookxinxi.add(addbook);
		
		delbook = new JMenuItem("ͼ����Ϣ�޸�");
		
		bookxinxi.add(delbook);
		
		menuItem_5 = new JMenuItem("\u56FE\u4E66\u4FE1\u606F\u68C0\u7D22");
		
		bookxinxi.add(menuItem_5);
		
		borrowadmin = new JMenu("���Ĺ���");
		menuBar.add(borrowadmin);
		
		borrowbook = new JMenuItem("ͼ�����");
		
		borrowadmin.add(borrowbook);
		
		returnbook = new JMenuItem("ͼ��黹");
		
		borrowadmin.add(returnbook);
		
		findborrow = new JMenuItem("���߽�������");
		
		borrowadmin.add(findborrow);
		
		ding = new JMenu("\u56FE\u4E66\u8BA2\u5355\u7BA1\u7406");
		
		menuBar.add(ding);
		
		menuItem = new JMenuItem("\u56FE\u4E66\u8BA2\u8D2D");
		
		ding.add(menuItem);
		
		menuItem_1 = new JMenuItem("\u56FE\u4E66\u9A8C\u6536");
		
		ding.add(menuItem_1);
		
		menu = new JMenu("\u7EF4\u62A4\u7CFB\u7EDF");
		menuBar.add(menu);
		
		menuItem_2 = new JMenuItem("\u6DFB\u52A0\u7BA1\u7406\u5458");
		
		menu.add(menuItem_2);
		
		menuItem_3 = new JMenuItem("\u5220\u9664\u7BA1\u7406\u5458");
		
		menu.add(menuItem_3);
		
		menuItem_4 = new JMenuItem("\u4FEE\u6539\u5BC6\u7801");
		
		menu.add(menuItem_4);
		frame.getContentPane().setLayout(null);
		
		label = new JLabel(new ImageIcon("33.png"));
		label.setBounds(0, 0, 590, 400);
		frame.getContentPane().add(label);
	}
	private void addListener() {
		addreader.addActionListener(new ActionListener() {//������Ϣ����
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Addreader window = new Addreader();
				window.frame.setVisible(true);
			}
		});
		delupreader.addActionListener(new ActionListener() {//������Ϣ�޸���ɾ��
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Updatareader window = new Updatareader();
				window.frame.setVisible(true);
			}
		});
		findereader.addActionListener(new ActionListener() {//������Ϣ����
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Queryreader window = new Queryreader();
				window.frame.setVisible(true);
			}
		});
		addtype.addActionListener(new ActionListener() {//ͼ���������
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Addtype window = new Addtype();
				window.frame.setVisible(true);
			}
		});
		updatatype.addActionListener(new ActionListener() {//ͼ������޸�
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Updatatype window = new Updatatype();
				window.frame.setVisible(true);
			}
		});
		addbook.addActionListener(new ActionListener() {//ͼ�� ��Ϣ ����
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Addbook window = new Addbook();
				window.frame.setVisible(true);
			}
		});
		delbook.addActionListener(new ActionListener() {//ͼ����Ϣ�޸�
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Upatabook window = new Upatabook();
				window.frame.setVisible(true);
			}
		});
		menuItem_5.addActionListener(new ActionListener() {//ͼ����Ϣ����
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Querybook window = new Querybook();
				window.frame.setVisible(true);
			}
		});
		borrowbook.addActionListener(new ActionListener() {//ͼ�����
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Borrow window = new Borrow();
				window.frame.setVisible(true);
			}
		});
		returnbook.addActionListener(new ActionListener() {//ͼ��黹
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Return window = new Return();
				window.frame.setVisible(true);
			}
		});
		findborrow.addActionListener(new ActionListener() {//���߽�������
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				BorrowList window = new BorrowList();
				window.frame.setVisible(true);
			}
		});
		menuItem.addActionListener(new ActionListener() {//ͼ�鶩��
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Buy window = new Buy();
				window.frame.setVisible(true);
			}
		});
		menuItem_1.addActionListener(new ActionListener() {   //ͼ������
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Check window = new Check();
				window.frame.setVisible(true);
			}
		});
		menuItem_2.addActionListener(new ActionListener() {  //���ӹ���Ա
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Addadmin window = new Addadmin();
				window.frame.setVisible(true);
			}
		});
		menuItem_3.addActionListener(new ActionListener() {   //ɾ������Ա
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Deladmin window = new Deladmin();
				window.frame.setVisible(true);
			}
		});
		menuItem_4.addActionListener(new ActionListener() {   //�޸�����
			public void actionPerformed(ActionEvent e) {
				if(Dnlu.admin.equals("")) {
					 JOptionPane.showMessageDialog(frame, "�㲢û�е�¼");
					 frame.dispose();
						Dnlu window = new Dnlu();
						window.frame.setVisible(true); frame.dispose();
				}
				else
				{
					frame.dispose();
					UpdataAdmin window = new UpdataAdmin();
					window.frame.setVisible(true);
				}
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
			            }
			  });
	}
}
