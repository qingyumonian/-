package service;

import java.util.ArrayList;
import java.util.Iterator;
import Vo.Rtype;
import dao.RtypeDao;

public class RtypeService { // �������
	private RtypeDao rtypedao = new RtypeDao();

	public RtypeService() {
		// TODO Auto-generated constructor stub
	}

	public ArrayList<Rtype> queryRtype() {
		ArrayList<Rtype> rtype = rtypedao.queryAllData();
		return rtype;
	}

	public Rtype findRtype1(String lxnumber) {

		Rtype t = rtypedao.findRtype1(lxnumber);

		return t;
	}

	public String findRtype(String lxname) {
		ArrayList<Rtype> m = queryRtype();
		Iterator<Rtype> iterator = m.iterator();
		String lnumber = null;
		while (iterator.hasNext()) {
			Rtype n = new Rtype();
			n = iterator.next();
			if (n.getLxname().equals(lxname)) {

				lnumber = n.getLxnumber();
				break;
			}
		}

		return lnumber;
	}

	public int findRtypeShu(String lxnumber) {  //���ؿɽ�����
		ArrayList<Rtype> m = queryRtype();
		Iterator<Rtype> iterator = m.iterator();
		int day = 0;
		while (iterator.hasNext()) {
			Rtype n = new Rtype();
			n = iterator.next();
			if (n.getLxnumber().equals(lxnumber)) {
				day = n.getKjamount();
				break;
			}
		}
		return day;
	}
}
