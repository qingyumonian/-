package view;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import Vo.Admin;
import service.AdminService;
import tools.GUITools;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Color;

public class UpdataAdmin {	//ά��ϵͳ-�޸�����

	 JFrame frame;

   private AdminService adminservice=new AdminService(); 
   private JLabel label_1;
   private JPasswordField passwordField;
   private JPasswordField passwordField_1;
   private JLabel label_3;
   private JLabel label_4;
   private JButton button_1;
   private JLabel label_2;
    private String  name="";
    private JLabel label_5;
    private JLabel titleLabel = new JLabel(new ImageIcon("1.jpg"));
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdataAdmin window = new UpdataAdmin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UpdataAdmin() {
		initialize();
		label_2.setText(Dnlu.admin);
		label_5 = new JLabel("");
		label_5.setForeground(Color.RED);
		label_5.setBounds(31, 259, 175, 15);
		frame.getContentPane().add(label_5);
		titleLabel.setBounds(0, 0, 443, 313);
		frame.getContentPane().add(titleLabel);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 443, 313);
		frame.setTitle("����Ա�޸�����");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"2.png");//����ͼ��
		frame.getContentPane().setLayout(null);
		
		label_1 = new JLabel("\u7BA1\u7406\u5458\u540D\u79F0\uFF1A");
		label_1.setBounds(64, 38, 95, 15);
		frame.getContentPane().add(label_1);
		
		label_2 = new JLabel("");
		label_2.setBounds(238, 38, 115, 21);
		frame.getContentPane().add(label_2);
		
		label_3 = new JLabel("\u8F93\u5165\u5BC6\u7801");
		label_3.setBounds(64, 106, 54, 15);
		frame.getContentPane().add(label_3);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(238, 103, 115, 21);
		frame.getContentPane().add(passwordField);
		
		label_4 = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		label_4.setBounds(64, 184, 74, 15);
		frame.getContentPane().add(label_4);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(233, 180, 120, 23);
		frame.getContentPane().add(passwordField_1);
		
		button_1 = new JButton("\u4FEE\u6539");
		button_1.addActionListener(new ActionListener() {  //�޸Ĳ���
			public void actionPerformed(ActionEvent e) {
				if(panDuan()) {//�ж��û����Ƿ�Ϊ��
					updataAdmin();
				}
			}
		});
		button_1.setBounds(138, 240, 93, 23);
		frame.getContentPane().add(button_1);
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				  new Dnlu().frame.setVisible(true);
		
			            }
			  });
	}
	
		public void findAdmin() {       
			label_2.setText(name);
		}
	public void updataAdmin() {
		String  administer=label_2.getText();
		char mima[]=passwordField.getPassword();
		char mima1[]=passwordField_1.getPassword();
		String passwords=new String(mima);
		String passwords_1=new String(mima1);
		Admin n=new Admin();
		n=adminservice.findAdmin(administer);
		if(passwords.equals(passwords_1)==false) {
			 JOptionPane.showMessageDialog(frame, "�������벻��ȷ������������");
			 passwordField.setText("");
			 passwordField_1.setText("");
		}
		else if(n.getPassword().equals(passwords))
		{
			 JOptionPane.showMessageDialog(frame, "�벻Ҫ�޸���֮ǰ���õ�һ��������");
			 passwordField.setText("");
			 passwordField_1.setText("");
			 
		} 
		else{
			boolean succ=adminservice.updataAdmin(administer, passwords);
				if(succ) {
					 JOptionPane.showMessageDialog(frame, "�޸ĳɹ�");
					 label_2.setText("");
					 passwordField.setText("");
					 passwordField_1.setText("");
				}	
				else  JOptionPane.showMessageDialog(frame, "�޸�ʧ��");
				}
		
	}
	public boolean panDuan() { //�ж��û�����Ϊ��
		String admin=label_2.getText();
		if(admin.equals("")) {
			JOptionPane.showMessageDialog(frame, "�û���Ϊ��");
			return false;
		}else {
			return  true;
		}
	}
}
