package service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import Vo.Reader;
import dao.ReaderDao;

public class ReaderService {
	private ReaderDao readerdao = new ReaderDao();
     private BorrowService borrowservice=new BorrowService();
	public ReaderService() {
		// TODO Auto-generated constructor stub
	}

	public ArrayList<Reader> queryReader() { // ��������
		ArrayList<Reader> reader = readerdao.queryAllData();
		return reader;

	}

	public Reader findReader(String jsnumber) {
		Reader reader = readerdao.findReader(jsnumber);
		return reader;
	}

	/*
	 * String jsnumber, String name, String sex, String phone, String institute,
	 * String zjname, String zjnumber, Date bjdate, String lxnumber
	 */
	public int addReader(String name, String sex, String phone, String institute, String zjname, String zjnumber,
			String lxnumber) {
		String str = zjnumber.substring(2, 4);
		String jsnumber;
		while (true) {
			jsnumber = null;
			String str1 = null;
			long t = Math.round(Math.random() * 999998 + 1);
			str1 = String.format("%06d", t);
			jsnumber = str + str1;
			if (chongFu(jsnumber)) {
				break;
			}
		}
		ArrayList<Reader> m = queryReader();
		Iterator<Reader> iterator = m.iterator();
		while (iterator.hasNext()) {
			Reader n = new Reader();
			n = iterator.next();
			if (n.getZjnumber().equals(zjnumber)) {
				return -1;
			}

		}
		Calendar canlendar = Calendar.getInstance(); // ��ȡϵͳʱ������
		java.util.Date date = canlendar.getTime(); // ����ʱ��util��ʱ��
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());// ʵ�ʹ黹ʱ��ת��
		Reader reader = new Reader(jsnumber, name, sex, phone, institute, zjname, zjnumber, sqlDate, lxnumber);
		boolean addSucc = readerdao.addReader(reader);
		if (addSucc)
			return 1;
		else
			return 0;
	}

	public int delReader(String jsnumber) {
		ArrayList<Reader> m = queryReader();
		Iterator<Reader> iterator = m.iterator();
		int flag = 0;
		if(borrowservice.panDuanBorrow(jsnumber))
		{
			flag=2;
		}
		while (iterator.hasNext()) {
			Reader n = new Reader();
			n = iterator.next();
			if (n.getJsnumber().equals(jsnumber)&&flag!=2) {
				if (readerdao.delReader(jsnumber))
					flag = 1;
				break;
			}

		}
		return flag;
	}

	public boolean updataReader(String jsnumber, String name, String sex, String phone, String institute, String zjname,
			String zjnumber, Date bjdate, String lxnumber) {
		ArrayList<Reader> m = queryReader();
		Iterator<Reader> iterator = m.iterator();
		int flag = 0;
		while (iterator.hasNext()) {
			Reader n = new Reader();
			n = iterator.next();
			if (n.getJsnumber().equals(jsnumber)) {
				flag = 1;
				break;
			}

		}
		if (flag == 1) {
			boolean updataSucc = readerdao.updataReader(jsnumber, name, sex, phone, institute, zjname, zjnumber, bjdate,
					lxnumber);
			if (updataSucc)
				return true;
		}
		return false;
	}

	public ArrayList<Reader> findReaderList(String institute) {
		ArrayList<Reader> m = queryReader();
		ArrayList<Reader> reader = new ArrayList<Reader>();
		Iterator<Reader> iterator = m.iterator();
		while (iterator.hasNext()) {
			Reader n = new Reader();
			n = iterator.next();
			if (n.getInstitute().equals(institute)) {
				reader.add(n);
			}
		}
		return reader;
	}

	public boolean chongFu(String jsnumber) {
		ArrayList<Reader> m = queryReader();
		Iterator<Reader> iterator = m.iterator();
		int flag = 0;
		while (iterator.hasNext()) {
			Reader n = new Reader();
			n = iterator.next();
			if (n.getJsnumber().equals(jsnumber)) {
				flag = 1;
				break;
			}
		}
		if (flag == 1)
			return false;
		else
			return true;
	}

}
