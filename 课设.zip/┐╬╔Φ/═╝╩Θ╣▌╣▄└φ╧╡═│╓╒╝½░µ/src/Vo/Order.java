package Vo;

import java.sql.Date;

public class Order {         //����

	      private String  tnumber;  //ͼ����
	      private String  tname;   //ͼ������
	      private String  author;   //����
	      private String  publish;   //������
	      private Double  price;     //����
	      private Date    dgdate;    //����ʱ��
	      private Integer dgquantity;  //����
	      private String  administer;  //����Ա
	      private String  checkout;    //�Ƿ�����
	
	public Order() {
		// TODO Auto-generated constructor stub
	}

	
	public Order(String tnumber, String tname, String author, String publish, Double price, Date dgdate,
			Integer dgquantity, String administer, String checkout) {
		super();
		this.tnumber = tnumber;
		this.tname = tname;
		this.author = author;
		this.publish = publish;
		this.price = price;
		this.dgdate = dgdate;
		this.dgquantity = dgquantity;
		this.administer = administer;
		this.checkout = checkout;
	}


	public String getTnumber() {
		return tnumber;
	}


	public void setTnumber(String tnumber) {
		this.tnumber = tnumber;
	}


	public String getTname() {
		return tname;
	}


	public void setTname(String tname) {
		this.tname = tname;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	public String getPublish() {
		return publish;
	}


	public void setPublish(String publish) {
		this.publish = publish;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public Date getDgdate() {
		return dgdate;
	}


	public void setDgdate(Date dgdate) {
		this.dgdate = dgdate;
	}


	public Integer getDgquantity() {
		return dgquantity;
	}


	public void setDgquantity(Integer dgquantity) {
		this.dgquantity = dgquantity;
	}


	public String getAdminister() {
		return administer;
	}


	public void setAdminister(String administer) {
		this.administer = administer;
	}


	public String getCheckout() {
		return checkout;
	}


	public void setCheckout(String checkout) {
		this.checkout = checkout;
	}


	@Override
	public String toString() {
		return "Order [tnumber=" + tnumber + ", tname=" + tname + ", author=" + author + ", publish=" + publish
				+ ", price=" + price + ", dgdate=" + dgdate + ", dgquantity=" + dgquantity + ", administer="
				+ administer + ", checkout=" + checkout + "]";
	}

}
