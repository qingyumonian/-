package service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import Vo.Order;
import dao.OrderDao;
import view.Dnlu;

/**
 * 
 * ���������
 * 
 */
public class OrderService {//����
	private OrderDao orderdao = new OrderDao();// *

	public OrderService() {
		// TODO Auto-generated constructor stub
	}

	public ArrayList<Order> queryOrder() {
		ArrayList<Order> order = orderdao.queryAllData();
		return order;
	}

	public boolean addOrder(String tnumber, String tname, String author, String publish, Double price,
			Integer dgquantity) {
		ArrayList<Order> m = queryOrder();
		Iterator<Order> iterator = m.iterator();
		while (iterator.hasNext()) {
			Order n = new Order();
			n = iterator.next();
			if (n.getTnumber().equals(tnumber)) {
				return false;
			}
		}
		/*
		 * String tnumber, String tname, String author, String publish, Double price,
		 * Date dgdate, Integer dgquantity, String administer, String checkout
		 */
		// System.out.println(tnumber);
		Calendar canlendar = Calendar.getInstance();
		java.util.Date date = canlendar.getTime();
		java.sql.Date sTime = new java.sql.Date(date.getTime());
		Order thisadmin = new Order(tnumber, tname, author, publish, price, sTime, dgquantity, Dnlu.admin, "��");
		boolean addSuccess = orderdao.addOrder(thisadmin);
		if (addSuccess) {
			return true;
		} else
			return false;
	}

	public boolean delOrder(String tnumber) {
		ArrayList<Order> m = queryOrder();
		Iterator<Order> iterator = m.iterator();
		int flag = 0;
		while (iterator.hasNext()) {
			Order n = new Order();
			n = iterator.next();
			if (n.getTnumber().equals(tnumber)) {
				boolean delSuccess = orderdao.delOrder(tnumber);
				if (delSuccess)
					flag = 1;
				break;
			}
		}
		if (flag == 1)
			return true;
		else
			return false;
	}

	public boolean updataOrder(String bnumber) {
		ArrayList<Order> m = queryOrder();
		Iterator<Order> iterator = m.iterator();
		int flag = 0;
		Order t = new Order();
		while (iterator.hasNext()) {
			Order n = new Order();
			n = iterator.next();
			t = n;
			if (n.getTnumber().equals(bnumber)) {
				flag = 1;
				break;
			}
		}
		if (flag == 1) {
			/*
			 * String tnumber, String tname, String author, String publish, Double price,
			 * Date dgdate, Integer dgquantity, String administer, String checkout
			 */
			boolean delSucc = orderdao.delOrder(bnumber);
			Order thisadmin = new Order(t.getTnumber(), t.getTname(), t.getAuthor(), t.getPublish(), t.getPrice(),
					t.getDgdate(), t.getDgquantity(), t.getAdminister(), "��");
			boolean addSucc = orderdao.addOrder(thisadmin);
			if (delSucc && addSucc)
				return true;
		}
		return false;
	}

	public ArrayList<Order> findOrder(String jsnumber) {
		ArrayList<Order> m = queryOrder();
		ArrayList<Order> order = new ArrayList<Order>();
		Iterator<Order> iterator = m.iterator();
		while (iterator.hasNext()) {
			Order n = new Order();
			n = iterator.next();
			if (n.getTnumber().equals(jsnumber)) {
				order.add(n);
			}
		}
		return order;
	}

	public ArrayList<Order> queryfalseOrder() {
		ArrayList<Order> m = queryOrder();
		ArrayList<Order> order = new ArrayList<Order>();
		Iterator<Order> iterator = m.iterator();
		while (iterator.hasNext()) {
			Order n = new Order();
			n = iterator.next();
			if (n.getCheckout().equals("��")) {
				order.add(n);
			}
		}
		return order;
	}

	public ArrayList<Order> querytrueOrder() {
		ArrayList<Order> m = queryOrder();
		ArrayList<Order> order = new ArrayList<Order>();
		Iterator<Order> iterator = m.iterator();
		while (iterator.hasNext()) {
			Order n = new Order();
			n = iterator.next();
			if (n.getCheckout().equals("��")) {
				order.add(n);
			}
		}
		return order;
	}
}
