package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import Vo.Book;
import Vo.Borrow;
import Vo.Reader;
import service.BookService;
import service.BorrowService;
import service.ReaderService;
import tools.GUITools;

import javax.swing.JScrollPane;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.Color;
import java.awt.EventQueue;

public class Return {	//���Ĺ���-ͼ��黹

	JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JLabel label;
	private JLabel label_1;
	private JButton button;
	private JTable table;
	private JScrollPane scrollPane;
	private JButton button_1;
	private BorrowService borrowservice = new BorrowService();
	private BookService bookservice = new BookService();
	private ReaderService readerservice=new ReaderService();
	private String type = null;
	private String jsnumber = "";
	private String bnumber = "";
	private JLabel label_2;
	 private JLabel titleLabel = new JLabel(new ImageIcon("7.png"));

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Return window = new Return();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public Return() {
		initialize();
		addListener();
		queryBook();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 610, 307);
		frame.getContentPane().setLayout(null);
		frame.setTitle("����ͼ��");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"4.png");//����ͼ��
		label = new JLabel("\u56FE\u4E66\u7F16\u53F7");
		label.setBounds(227, 25, 54, 15);
		frame.getContentPane().add(label);

		label_1 = new JLabel("\u501F\u4E66\u8BC1\u53F7");
		label_1.setBounds(33, 25, 54, 15);
		frame.getContentPane().add(label_1);

		textField = new JTextField();
		
		textField.setBounds(111, 22, 93, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		
		textField_1.setBounds(309, 22, 93, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);

		button = new JButton("\u786E\u8BA4\u5F52\u8FD8");

		button.setBounds(252, 235, 93, 23);
		frame.getContentPane().add(button);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 50, 586, 159);
		frame.getContentPane().add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);

		button_1 = new JButton("\u67E5\u8BE2");

		button_1.setBounds(470, 21, 93, 23);
		frame.getContentPane().add(button_1);
		
		label_2 = new JLabel("");
		label_2.setForeground(Color.RED);
		label_2.setBounds(20, 239, 222, 15);
		frame.getContentPane().add(label_2);
		
		titleLabel.setBounds(0, 0,610, 350);
		frame.getContentPane().add(titleLabel);
	}

	public void addListener() {
		button_1.addActionListener(new ActionListener() { // ��ѯ
			public void actionPerformed(ActionEvent arg0) {
				String jsnumber=textField.getText();
				String bnumber=textField_1.getText();
				//System.out.println(jsnumber+"1"+bnumber+"2");
				if(jsnumber.equals("")) {
					label_2.setText("����֤�Ų���Ϊ��");
				}
				else if(bnumber.equals("")) {
					label_2.setText("��Ų���Ϊ��");
				}else {
					label_2.setText("");
					ArrayList<Borrow>borrow=borrowservice.queryBorrow();
					Iterator<Borrow>iterator_1=borrow.iterator();
					int flag1=0;
					while(iterator_1.hasNext()) {    //�ҵ�������ļ�¼
						Borrow n=new Borrow();
						n=iterator_1.next();
						if(n.getBnumber().equals(bnumber)&&n.getJsnumber().equals(jsnumber))
						{
							flag1=1;
							break;
						}
					}
					if(flag1==0) {
						JOptionPane.showMessageDialog(frame, "���ļ�¼���沢û���Ȿ��");
						textField_1.setText("");
					}else {
						label_2.setText("");
						queryBook1();
					}
				}
			}
		});
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // ����ͼ���� �ͽ���֤�� ȷ�Ϲ黹
				if(jsnumber.equals("")) {
					label_2.setText("����֤�Ų���Ϊ��");
				}
				else if(bnumber.equals("")) {
					label_2.setText("��Ų���Ϊ��");
				     }
					else {
						rbook();
					}
			}
		});
		textField.addFocusListener(new FocusAdapter() {   //������֤
			@Override
			public void focusLost(FocusEvent arg0) {
				type = "ѧ��";
				String jsnumber=textField.getText();
				ArrayList<Reader>reader=readerservice.queryReader();
				Iterator<Reader>iterator=reader.iterator();
				int flag=0;
				int flag1=0;
				while(iterator.hasNext()) {    //��֤�����Ƿ����
					Reader m=new Reader();
					m=iterator.next();
					if(jsnumber.equals("")) {
						flag=2;
						flag1=2;
						break;
					}
						
					else if(m.getJsnumber().equals(jsnumber))
					{
						if(m.getLxnumber().equals("002")) {
							type="��ʦ";
						}
						flag=1;
						break;
					}
				}
				if(flag==0) {
					JOptionPane.showMessageDialog(frame, "���߲�����");
					textField.setText("");
				}
				ArrayList<Borrow>borrow=borrowservice.queryBorrow();
				Iterator<Borrow>iterator_1=borrow.iterator();
				while(iterator_1.hasNext()) {   //��֤���ļ�¼֤�Ƿ���������߽���
					Borrow n=new Borrow();
					n=iterator_1.next();
					if(n.getJsnumber().equals(jsnumber))
					{
						flag1=1;
						break;
					}
				}
				if(flag==1&&flag1==0) {
					JOptionPane.showMessageDialog(frame, "��λ���߲�û�н����¼");
					textField.setText("");
				}
			}
		});
		textField_1.addFocusListener(new FocusAdapter() {    //ͼ���ż���
			@Override
			public void focusLost(FocusEvent arg0) {
				String bnumber=textField_1.getText();
				ArrayList<Book>book=bookservice.queryBook();
				Iterator<Book>iterator=book.iterator();
				int flag=0;
				while(iterator.hasNext()) {      //��֤ͼ���Ƿ����
					Book m=new Book();
					m=iterator.next();
					if(bnumber.equals("")) {
						flag=2;
						break;
					}
					else if(m.getBnumber().equals(bnumber))
					{
						flag=1;
						break;
					}
				}
				if(flag==0) {
					JOptionPane.showMessageDialog(frame, "ͼ�鲻����");
					textField_1.setText("");
				}
			}
			
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
	}

	public void rbook() {
		jsnumber = textField.getText();
		bnumber = textField_1.getText();
		int succ = borrowservice.returnBook(jsnumber, bnumber);
		//boolean succ1=borrowservice.delBorrow(jsnumber, bnumber);
		if (succ == -1) {
			JOptionPane.showMessageDialog(frame, "ͼ���ѹ黹");
			textField.setText("");
			textField_1.setText("");
		} else if (succ == 1) {
			
			JOptionPane.showMessageDialog(frame, "�黹�ɹ�");
			queryBook();
			textField.setText("");
			textField_1.setText("");
			
		} else 
			JOptionPane.showMessageDialog(frame, "�黹ʧ��");

	}

	public void queryBook() {
		// �������ͷ

		String[] thead = { "����֤��", "��������", "ͼ����", "����", "����ʱ��", "�黹����" };
		// ����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
		String[][] tbody = null;
		// ����ѯ���Ľ��Ϊtable��ֵ
		TableModel dataModel = new DefaultTableModel(tbody, thead);
		table.setModel(dataModel);
	}

	public void queryBook1() {
		// �������ͷ

		String[] thead = { "����֤��", "��������", "ͼ����", "����", "����ʱ��", "�黹����" };
		jsnumber = textField.getText();
		bnumber = textField_1.getText();
		// ����adminService�Ĳ�ѯ����
		//System.out.println(jsnumber+"1"+bnumber+"2");
		Borrow dataList = borrowservice.findBorrow(jsnumber, bnumber);
		// ����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
		String[][] tbody = listToArray(dataList);
		// ����ѯ���Ľ��Ϊtable��ֵ
		TableModel dataModel = new DefaultTableModel(tbody, thead);
		table.setModel(dataModel);
	}

	// ��������תΪ��ά����
	private String[][] listToArray(Borrow n) { // ����ת��ΪString��ά����
		String[][] tbody = new String[1][6];

		Book m = bookservice.findBook(n.getBnumber());
		tbody[0][0] = n.getJsnumber();
		tbody[0][1] = type;
		tbody[0][2] = n.getBnumber();
		tbody[0][3] = m.getBname();
		tbody[0][4] = n.getBorrowdate() + "";
		tbody[0][5] = n.getReturndate() + "";
		return tbody;

	}
}
