package service;

import java.util.ArrayList;
import java.util.Iterator;
import Vo.Admin;
import dao.AdminDao;

public class AdminService {   //����Ա����㣬���ӣ��޸ģ�ɾ��
	private AdminDao adminDao = new AdminDao();//����dao�����
	public AdminService() {
		// TODO Auto-generated constructor stub
	}
	public ArrayList<Admin> queryAdmin(){// ����DAO�� ���м���
		ArrayList <Admin> admin=adminDao.queryAllData();
		return admin;
	}
	 public Admin findAdmin(String administer){// ʵ�ֲ��ҵķ���
	    	Admin admin=adminDao.findAdmin(administer);
	    	return admin;
	    }
	public boolean addAdmin(String administer,String passwords) {//ʵ������
		ArrayList<Admin> m=queryAdmin();
		Iterator<Admin>iterator=m.iterator();
		while (iterator.hasNext())
		{
	     	Admin n=new Admin(); 
	     	n=iterator.next();
		     if(n.getAdminister().equals(administer))
		     {
		    	 return false;
		     }
			
		}
		Admin thisadmin=new Admin(administer,passwords);
		adminDao.addAdmin(thisadmin);
		return true;
		
	}
	public boolean delAdmin(String administer) { //ʵ��ɾ��
		ArrayList<Admin> m=queryAdmin();
		Iterator<Admin>iterator=m.iterator();
		int flag=0;
		while (iterator.hasNext())
		{
	     	Admin n=new Admin(); 
	     	n=iterator.next();
		     if(n.getAdminister().equals(administer))
		     {
		    	 flag=1;
		    	adminDao.delAdmin(administer);
		    	break;
		     }
			
		}
		if(flag==1)
		return true;
		else return false;
	}
	public boolean updataAdmin(String administer,String passwords) {
		ArrayList<Admin> m=queryAdmin();
		Iterator<Admin>iterator=m.iterator();
		int flag=0;
		while (iterator.hasNext())
		{
	     	Admin n=new Admin(); 
	     	n=iterator.next();
		     if(n.getAdminister().equals(administer))
		     {
		    	 flag=1;
		    	break;
		     }
			
		}
		if(flag==1)
		{
			boolean succ=adminDao.updataAdmin(administer, passwords);
			if(succ)
			return true;
		}
		
		 return false;
	}
	
}
