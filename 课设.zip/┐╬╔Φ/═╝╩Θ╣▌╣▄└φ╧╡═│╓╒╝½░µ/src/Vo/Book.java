package Vo;

import java.sql.Date;



public class Book {   //ͼ��
 
	      private String  bnumber;
	      private String  bname;
	      private String  author;
	      private String  publish;//������
	      private Double  price;
	      private Integer amount;//����
	      private String  sjnumber; //��ܱ��
	      private Date    rkdate;//�������
	      private String  lnumber;//ͼ�����ͱ��
	
	public Book() {
		// TODO Auto-generated constructor stub
	}

	public Book(String bnumber, String bname, String author, String publish, Double price, Integer amount,
			String sjnumber, Date rkdate, String lnumber) {
		super();
		this.bnumber = bnumber;
		this.bname = bname;
		this.author = author;
		this.publish = publish;
		this.price = price;
		this.amount = amount;
		this.sjnumber = sjnumber;
		this.rkdate = rkdate;
		this.lnumber = lnumber;
	}

	public String getBnumber() {
		return bnumber;
	}

	public void setBnumber(String bnumber) {
		this.bnumber = bnumber;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublish() {
		return publish;
	}

	public void setPublish(String publish) {
		this.publish = publish;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public String getSjnumber() {
		return sjnumber;
	}

	public void setSjnumber(String sjnumber) {
		this.sjnumber = sjnumber;
	}

	public Date getRkdate() {
		return rkdate;
	}

	public void setRkdate(Date rkdate) {
		this.rkdate = rkdate;
	}

	public String getLnumber() {
		return lnumber;
	}

	public void setLnumber(String lnumber) {
		this.lnumber = lnumber;
	}

	@Override
	public String toString() {
		return "Book [bnumber=" + bnumber + ", bname=" + bname + ", author=" + author + ", publish=" + publish
				+ ", price=" + price + ", amount=" + amount + ", sjnumber=" + sjnumber + ", rkdate=" + rkdate
				+ ", lnumber=" + lnumber + "]";
	}
    
}
