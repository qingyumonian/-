package view;


import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import Vo.Book;

import Vo.Reader;
import service.BookService;
import service.BorrowService;
import service.ReaderService;
import tools.GUITools;

import javax.swing.JScrollPane;


public class Borrow {	//���Ĺ���-ͼ�����

	JFrame frame;
	private JTextField textField;
	private JTable table;
	private JLabel label;
	private JButton button;
	private JButton button_1;
	private JLabel label_1;
	private JTextField textField_1;
	private JLabel lblNewLabel;
	private JScrollPane scrollPane;
	private BookService bookservice=new BookService();
	private BorrowService borrowservice=new BorrowService();
    private ReaderService readerservice=new ReaderService();
	private String bnumber=null;
	 private JLabel titleLabel = new JLabel(new ImageIcon("7.png"));
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Borrow window = new Borrow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * Create the application.
	 */
	public Borrow() {
		initialize();
		addListener();
		queryBorrow();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setTitle("ͼ�����");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"4.png");//����ͼ��
		frame.getContentPane().setLayout(null);
		
		label = new JLabel("\u56FE\u4E66\u7F16\u53F7:");
		label.setBounds(41, 20, 80, 15);
		frame.getContentPane().add(label);
		
		textField = new JTextField();
		textField.setBounds(131, 17, 66, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		button = new JButton("\u67E5\u8BE2");
		
		button.setBounds(255, 16, 93, 23);
		frame.getContentPane().add(button);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 49, 434, 98);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		button_1 = new JButton("\u501F\u9605");
		
		button_1.setBounds(255, 162, 93, 23);
		frame.getContentPane().add(button_1);
		
		label_1 = new JLabel("\u6CE8\uFF1A\u56FE\u4E66\u5982\u6709\u635F\u574F\uFF0C\u53CC\u500D\u8D54\u507F");
		label_1.setBounds(41, 212, 190, 15);
		label_1.setForeground(Color.RED);
		frame.getContentPane().add(label_1);
		
		lblNewLabel = new JLabel("\u8BFB\u8005\u501F\u4E66\u8BC1\u53F7");
		lblNewLabel.setBounds(41, 166, 80, 15);
		frame.getContentPane().add(lblNewLabel);
		
		textField_1 = new JTextField();
		textField_1.setBounds(131, 163, 66, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		titleLabel.setBounds(0, 0,450, 300);
		frame.getContentPane().add(titleLabel);
	}
	public void addListener() {
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {// ����ͼ���Ų�ѯ����ʾͼ����Ϣ
				String bnumber =textField.getText();
				ArrayList<Book>book=bookservice.queryBook();
				Iterator<Book>iterator=book.iterator();
				int flag=0;
				while(iterator.hasNext()) {
					Book m=new Book();
					m=iterator.next();
					if(m.getBnumber().equals(bnumber)) {
						flag=1;
						break;
					   }
					}
				if(flag==1) {
					find();
				 }else JOptionPane.showMessageDialog(frame, "ͼ��ݲ�û���Ȿ��");				 		
			}
		});
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {//����
				String jsnumber=textField_1.getText();
				ArrayList<Reader>reader=readerservice.queryReader();
				Iterator<Reader>iterator_1=reader.iterator();
				int flag1=0;
				while(iterator_1.hasNext()) {
					Reader n=new Reader();
					n=iterator_1.next();
					if(n.getJsnumber().equals(jsnumber)) {
						flag1=1;
						break;
					}
				}
				if(flag1==1)
				jieYue();
				else JOptionPane.showMessageDialog(frame, "û���������");
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
	}
	public void jieYue() {
		
		String bnumber=textField.getText();
		String jsnumber=textField_1.getText();
		int succ=borrowservice.addBorrow(jsnumber, bnumber);
		if(succ==-3)JOptionPane.showMessageDialog(frame, "���ѽ���Ȿ�黹û�й黹");
		else if(succ==-2)JOptionPane.showMessageDialog(frame, "���ѳ����ɽ�����");
		else if(succ==-1)JOptionPane.showMessageDialog(frame, "����ͼ��û����ָ����ʱ��黹");
		else if(succ==2)JOptionPane.showMessageDialog(frame, "ͼ��ݿ�治����");
		else if(succ==1)
		 {
			 JOptionPane.showMessageDialog(frame, "���ĳɹ�");
			 textField.setText("");
			 textField_1.setText("");
		 }
				else if(succ==0) JOptionPane.showMessageDialog(frame, "����ʧ��");
	}
		public void queryBorrow(){
				//�������ͷ
				String[] thead = {"ͼ����","����","����","���浥λ"};
				String[][] tbody = null;
				TableModel dataModel = new DefaultTableModel(tbody,thead);
				table.setModel(dataModel);		
			}
	public void find(){
		
		 bnumber=textField.getText();
		//�������ͷ
		String[] thead = {"ͼ����","����","����","���浥λ"};
		//����Service�Ĳ�ѯ����
		Book dataList =bookservice.findBook(bnumber);;
		//����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
		String[][] tbody = listToArray(dataList);
		//����ѯ���Ľ��Ϊtable��ֵ
		TableModel dataModel = new DefaultTableModel(tbody,thead);
		table.setModel(dataModel);		
	}
	// ��������תΪ��ά����
	private String[][] listToArray(Book n) {   //����ת��ΪString��ά����
		String[][] tbody = new String[1][4];
					tbody[0][0] = n.getBnumber();
					tbody[0][1] = n.getBname();
					tbody[0][2] = n.getAuthor();
					tbody[0][3] = n.getPublish();
			
			return tbody;
		}
}
