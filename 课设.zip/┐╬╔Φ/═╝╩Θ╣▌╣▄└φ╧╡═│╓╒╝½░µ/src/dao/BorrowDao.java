package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import Vo.Borrow;
import dbc.JDBCUtils;

/**
 * ���Ĺ���Dao��� �� ɾ �� 
 *
 */
public class BorrowDao {

	public ArrayList<Borrow> queryAllData(){
		Connection conn=null;
		Statement  stmt=null;
		ResultSet rs=null;
		ArrayList<Borrow> borrow=new ArrayList<Borrow>();
		try {
			conn=JDBCUtils.getConnection(1);
			stmt=conn.createStatement();
			String sql="select jsnumber,bnumber,borrowdate,returndate from Borrow";
			rs=stmt.executeQuery(sql);
			while(rs.next()) {
				Borrow m=new Borrow();
				m.setJsnumber(rs.getString("jsnumber"));
				m.setBnumber(rs.getString("bnumber"));
				m.setBorrowdate(rs.getDate("borrowdate"));
				m.setReturndate(rs.getDate("returndate"));
				borrow.add(m);
			}
		return borrow;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return null;
	}
	
	public boolean addBorrow(Borrow m) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try {
			conn=JDBCUtils.getConnection(1);
			String sql="insert into Borrow (jsnumber,bnumber,borrowdate,returndate) values (?,?,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, m.getJsnumber());
			pstmt.setString(2, m.getBnumber());
			pstmt.setDate(3, m.getBorrowdate());
			pstmt.setDate(4, m.getReturndate());

			if(pstmt.executeUpdate()>0)
			{
				result=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	public boolean delBorrow(String jsnumber,String bnumber) {
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try{
			conn=JDBCUtils.getConnection(1);
			String  sql="delete from Borrow where jsnumber=? and bnumber=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, jsnumber);
			pstmt.setString(2, bnumber);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	 public Borrow findBorrow(String jsnumber,String bnumber) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			Borrow m = new Borrow();
			try{
				conn = JDBCUtils.getConnection(1);
				String sql = "select jsnumber,bnumber,borrowdate,returndate from Borrow where jsnumber=? and bnumber=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, jsnumber);
				pstmt.setString(2, bnumber);
				rs = pstmt.executeQuery();	
				if(rs == null)
					m = null;
				if(rs.next()){				
					m.setJsnumber(rs.getString("jsnumber"));
					m.setBnumber(rs.getString("bnumber"));
					m.setBorrowdate(rs.getDate("borrowdate"));
					m.setReturndate(rs.getDate("returndate"));			
				}			
			}catch(Exception e ){
				e.printStackTrace();
			}finally{
				JDBCUtils.close(conn);
			}
			return m;		
		}
}
