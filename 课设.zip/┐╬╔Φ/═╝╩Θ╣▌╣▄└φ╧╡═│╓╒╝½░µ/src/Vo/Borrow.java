package Vo;

import java.sql.Date;

public class Borrow {    //���ļ�¼

	
	      private String  jsnumber;  //����֤��
	      private String  bnumber;   //���
	      private Date    borrowdate;  //����ʱ��
	      private Date    returndate;//Ӧ��ʱ��
	    
	      
	public Borrow() {
		// TODO Auto-generated constructor stub
	}


	public Borrow(String jsnumber, String bnumber, Date borrowdate, Date returndate) {
		super();
		this.jsnumber = jsnumber;
		this.bnumber = bnumber;
		this.borrowdate = borrowdate;
		this.returndate = returndate;
	}


	public String getJsnumber() {
		return jsnumber;
	}


	public void setJsnumber(String jsnumber) {
		this.jsnumber = jsnumber;
	}


	public String getBnumber() {
		return bnumber;
	}


	public void setBnumber(String bnumber) {
		this.bnumber = bnumber;
	}


	public Date getBorrowdate() {
		return borrowdate;
	}


	public void setBorrowdate(Date borrowdate) {
		this.borrowdate = borrowdate;
	}


	public Date getReturndate() {
		return returndate;
	}


	public void setReturndate(Date returndate) {
		this.returndate = returndate;
	}

	

}
