package dbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * �������ݿ����Ӻ͹رղ����Լ�ȡ��һ�����ݿ�����Ӷ���
 * 
 */
public class JDBCUtils {
	public static final int CONNECTION_MYSQL=2;
	public static final int CONNECTION_SQL=1;	
	public JDBCUtils() {	}
	/*
	 * ��ȡ���Ӷ���
	 */
	public static Connection getConnection(int connection_type)throws Exception
	{
		switch (connection_type)
		{
			case CONNECTION_SQL:
				return getConnectionSQL();
			case CONNECTION_MYSQL:
				return getConnectionMYSQL();
		}
		return null;
	}
	
	/*
	 * ����SQLSERVER���ݿ�
	 */	
	private static Connection getConnectionSQL()
	{
		Connection conn=null;
		final String DBDRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";//��������
		final String DBURL = "jdbc:sqlserver://localhost:1433;databaseName=library";
		final String DBUSER = "theking";
		final String DBPASS = "1217";		
		try {
			Class.forName(DBDRIVER);
			conn=DriverManager.getConnection(DBURL,DBUSER,DBPASS);//��ȡ���Ӷ���
		} catch (ClassNotFoundException e) {				
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return conn;
	}	
	/*
	 * ����MYSQL���ݿ�
	 */
	private static Connection getConnectionMYSQL()
	{
		final String DBDRIVER = "com.mysql.jdbc.Driver";
		final String DBURL = "jdbc:mysql://localhost:3306/library";
		final String DBUSER = "������";
		final String DBPASS = "qwerty123";
		Connection conn=null;		
		try
		{
			Class.forName(DBDRIVER); 			
			conn=DriverManager.getConnection(DBURL,DBUSER,DBPASS);			
		} catch (ClassNotFoundException e) {				
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return conn;
	}
	/*
	 * �ر����Ӷ���
	 */
	public static void close(Connection conn)
	{
		if(conn!=null)
		{
			try
			{
				conn.close();
			} catch(SQLException e)
			{
				e.printStackTrace();				
			}
			conn = null;
		}
	}	
}