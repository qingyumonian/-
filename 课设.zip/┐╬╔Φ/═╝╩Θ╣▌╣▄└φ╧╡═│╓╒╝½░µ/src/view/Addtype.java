package view;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import Vo.Btype;
import service.BtypeService;
import tools.GUITools;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Addtype {   //ͼ����Ϣ����-������-ͼ���������

	JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTable table;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JScrollPane scrollPane;
	private JButton button;
	private JLabel label_3;
	private BtypeService btypeservice=new BtypeService();
	private JLabel titleLabel = new JLabel(new ImageIcon("6.jpg"));
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Addtype window = new Addtype();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the application.
	 */
	public Addtype() {
		initialize();
		addListener();
		queryType();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 400);
		frame.setTitle("ͼ����������");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"3.png");//����ͼ��
		frame.getContentPane().setLayout(null);
		
		label = new JLabel("\u7C7B\u522B\u7F16\u53F7\uFF1A");
		label.setBounds(62, 222, 75, 15);
		frame.getContentPane().add(label);
		
		textField = new JTextField();
		
		textField.setBounds(226, 219, 113, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		label_1 = new JLabel("\u7C7B\u522B\u540D\u79F0\uFF1A");
		label_1.setBounds(62, 175, 75, 15);
		frame.getContentPane().add(label_1);
		
		textField_1 = new JTextField();
		
		textField_1.setBounds(226, 169, 113, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		label_2 = new JLabel("\u53EF\u501F\u5929\u6570\uFF1A");
		label_2.setBounds(62, 267, 75, 15);
		frame.getContentPane().add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(226, 264, 113, 21);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 44, 414, 121);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		button = new JButton("\u6DFB\u52A0");
		
		button.setBounds(136, 322, 93, 23);
		frame.getContentPane().add(button);
		
		label_3 = new JLabel("\u56FE\u4E66\u7C7B\u522B");
		label_3.setBounds(186, 19, 54, 15);
		frame.getContentPane().add(label_3);
		
		titleLabel.setBounds(0, 0, 600, 600);
		frame.getContentPane().add(titleLabel);
	}
     public void addListener() {
    	 
    	 button.addActionListener(new ActionListener() {  //����
 			public void actionPerformed(ActionEvent e) {
 				if(panDuan()) {//�ɽ�����int ��С  �������� ���ͱ��
 					tianJia();
 					queryType();
 				}
 				
 			}
 		});
    	 textField_1.addFocusListener(new FocusAdapter() {  //ͼ��������Ƽ���
 			@Override
 			public void focusLost(FocusEvent e) {
 				String btype =textField_1.getText();
 				ArrayList <Btype>m=btypeservice.queryBtype();
 				Iterator<Btype>n=m.iterator();
 				while(n.hasNext()) {
 					Btype t=new Btype();
 					t=n.next();
 					if(t.getLname().equals(btype))
 					{
 						JOptionPane.showMessageDialog(frame, "������Ѿ�����");
 						textField_1.setText("");
 						break;
 					}
 					
 				}
 			}
 		});
    	 textField.addFocusListener(new FocusAdapter() {  //ͼ������ż���
 			@Override
 			public void focusLost(FocusEvent e) {
 				String lxnumber =textField.getText();
 				ArrayList <Btype>m=btypeservice.queryBtype();
 				Iterator<Btype>n=m.iterator();
 				while(n.hasNext()) {
 					Btype t=new Btype();
 					t=n.next();
 					if(t.getLnumber().equals(lxnumber))
 					{
 						JOptionPane.showMessageDialog(frame, "�ñ���Ѿ�����");
 						textField.setText("");
 						break;
 					}
 				}
 			}
 		});
    	 frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  }); 
     }
     public void  tianJia() {
    	// String lnumber, String lname, Integer kjday
    	 String  lname=textField_1.getText();
    	 String lnumber=textField.getText();
    	 String kjday=textField_2.getText();
    	 boolean succ=btypeservice.addBtype(lnumber, lname, Integer.valueOf(kjday));
    	 if(succ) {
			 JOptionPane.showMessageDialog(frame, "���ӳɹ�");
			 queryType();
			 textField.setText("");
			 textField_1.setText("");
			 textField_2.setText("");
		 }
				else JOptionPane.showMessageDialog(frame, "����ʧ��");

     }
     public boolean panDuan() {
    	 String  lname=textField_1.getText();
    	 String lnumber=textField.getText();
    	 String kjday=textField_2.getText();
    	 boolean succ1=kjday.matches("[0-9]{1,6}");
     	if(succ1==false) {
     		JOptionPane.showMessageDialog(frame, "������͵Ŀɽ���������int����");
     	    textField_2.setText("");
     	    return false;
     	}
     	 if(succ1==true){
     		int m=kjday.length();
     		if(m>4) {
     			JOptionPane.showMessageDialog(frame, "�Ȿ��Ŀɽ�����̫���ˣ�����������");
     			 textField_2.setText("");
     			 return false;
     		}
     		 if(lname.equals("")) {
    		     JOptionPane.showMessageDialog(frame, "�������Ʋ���Ϊ��");
	    		 return false;
	    	 } if(lnumber.equals("")) {
	    		 JOptionPane.showMessageDialog(frame, "���ͱ�Ų���Ϊ��");
	    		 return false;
	    	 } if(kjday.equals("")) {
	    		 JOptionPane.showMessageDialog(frame, "�ɽ���������Ϊ��");
	    		 return false;
	    	 }
         }
     	 return true ;
     }
	// ��ѯ����
			public void queryType() {          //ˢ�±������������
				// �������ͷ
				String[] thead = { "�����", "�������", "�ɽ�����"};
				// ����adminService�Ĳ�ѯ����
				ArrayList<Btype> dataList =btypeservice.queryBtype();
				// ����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
				String[][] tbody = listToArray(dataList);
				// ����ѯ���Ľ��Ϊtable��ֵ
				TableModel dataModel = new DefaultTableModel(tbody, thead);
				table.setModel(dataModel);
			}
			// ��������תΪ��ά����
			private String[][] listToArray(ArrayList<Btype> list) {   //����ת��ΪString��ά����
				String[][] tbody = new String[list.size()][3];
				for (int i = 0; i < list.size(); i++) {
					Btype n = list.get(i);
					tbody[i][0] = n.getLnumber();
					tbody[i][1] = n.getLname();
					tbody[i][2] = n.getKjday()+"";
				}
				return tbody;
			}
}
