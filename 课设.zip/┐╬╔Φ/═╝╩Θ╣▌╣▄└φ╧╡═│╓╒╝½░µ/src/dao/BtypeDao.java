package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import Vo.Btype;
import dbc.JDBCUtils;

public class BtypeDao {

	public BtypeDao() {
		// TODO Auto-generated constructor stub
	}
	public ArrayList<Btype>  queryAllData(){   //����ͼ�����ļ���
		
		Connection conn=null;
		Statement  st=null;
		ResultSet rs=null;
		ArrayList <Btype> user=new ArrayList<Btype>();
		try{
			conn=JDBCUtils.getConnection(1);
			st=conn.createStatement();
			String sql="select lnumber,lname,kjday from Btype";
			rs=st.executeQuery(sql);
			while(rs.next())
			{
				Btype m=new Btype();
				m.setLnumber(rs.getString("lnumber"));
				m.setLname(rs.getString("lname"));
				m.setKjday(rs.getInt("kjday"));
				user.add(m);
			}
			return user;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return null;
		
	}
	public boolean   addBtype(Btype m){//����Ա������
		Connection conn=null;
		PreparedStatement  pstmt=null;
		boolean  result=false;
		try{
			conn=JDBCUtils.getConnection(1);
			String sql="insert into Btype(lnumber,lname,kjday)values(?,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, m.getLnumber());
			pstmt.setString(2, m.getLname());
			pstmt.setInt(3, m.getKjday());
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	public  boolean  delBtype(String  lnumber){      //����Ա��ɾ��
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try{
			conn=JDBCUtils.getConnection(1);
			String sql="delete from Btype where lnumber = ?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,lnumber);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	public  boolean  updataBtype(String lnumber, String lname, Integer kjday){      //ͼ�����͸���
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try{
			conn=JDBCUtils.getConnection(1);
			String sql="update Btype set lname = ? , kjday = ? where lnumber like ?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,lname);
			pstmt.setInt(2, kjday);
			pstmt.setString(3, lnumber);;
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	public Btype findBtype1(String lnumber) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Btype m=new Btype();
		try{
			conn = JDBCUtils.getConnection(1);
			String sql = "select lnumber,lname,kjday from Btype where lnumber =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, lnumber);
			rs = pstmt.executeQuery();	
			if(rs == null)
				m = null;
			if(rs.next()){				
				m.setLnumber(rs.getString("lnumber"));
				m.setLname(rs.getString("lname"));
				m.setKjday(rs.getInt("kjday"));
			}			
		}catch(Exception e ){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return m;		
		
	}
}
