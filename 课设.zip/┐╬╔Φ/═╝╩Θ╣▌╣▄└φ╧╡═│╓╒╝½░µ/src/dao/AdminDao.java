package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import dbc.JDBCUtils;
import Vo.Admin;
/**
 * ����ԱDao��� �� ɾ ��
 */
public class AdminDao {

	public ArrayList<Admin>  queryAllData(){   //���ع���Ա�ļ���
		Connection conn=null;
		Statement  st=null;
		ResultSet rs=null;//���������
		ArrayList <Admin> user=new ArrayList<Admin>();
		try{
			conn=JDBCUtils.getConnection(1);
			st=conn.createStatement();//�������� �Ա�ִ��sql���
			String sql="select administer,passwords from Admins";
			rs=st.executeQuery(sql);
			while(rs.next())
			{
				Admin admin=new Admin();
				admin.setAdminister(rs.getString("administer"));
				admin.setPassword(rs.getString("passwords"));
				user.add(admin);
			}
			return user;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return null;
	}
	public boolean   addAdmin(Admin m){//����Ա������
		Connection conn=null;
		PreparedStatement  pstmt=null;
		boolean  result=false;
		try{
			conn=JDBCUtils.getConnection(1);
			String sql="insert into Admins(administer,passwords)values(?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, m.getAdminister());
			pstmt.setString(2, m.getPassword());
			int num=pstmt.executeUpdate();// �������������
			if(num>0)
			{
				result=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	public  boolean  delAdmin(String  administer){      //����Ա��ɾ��
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try{
			conn=JDBCUtils.getConnection(1);
			String sql="delete from Admins where administer=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,administer);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	public  boolean updataAdmin(String  administer,String passwords){      //����Ա���޸�
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try{
			conn=JDBCUtils.getConnection(1);
			String sql="update Admins set passwords=? where administer=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,passwords);
			pstmt.setString(2,administer);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	public Admin findAdmin(String administer) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Admin admin = new Admin();
		try{
			conn = JDBCUtils.getConnection(1);
			String sql = "select administer,passwords from Admins where administer = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, administer);
			rs = pstmt.executeQuery();	
			if(rs == null)
				admin = null;
			if(rs.next()){				
				admin.setAdminister(rs.getString("administer"));
				admin.setPassword(rs.getString("passwords"));						
			}			
		}catch(Exception e ){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return admin;		
	}
}
