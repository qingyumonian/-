package view;
import java.awt.Button;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import Vo.Book;
import Vo.Borrow;
import Vo.Reader;
import service.BookService;
import service.BorrowService;
import service.ReaderService;
import tools.GUITools;

import javax.swing.JScrollPane;

public class BorrowList {	//���Ĺ���-���߽�������

	JFrame frame;
	private JTable table;
	private JTextField textField;
	private JLabel label_1;
	private JLabel label;
	private JButton button;
	private BorrowService borrowservice=new BorrowService();
	private BookService bookservice=new BookService();
	private ReaderService readerservice=new ReaderService();
	private String type=null;
	private String jsnumber=null;
	private JScrollPane scrollPane;
	 private JLabel titleLabel = new JLabel(new ImageIcon("7.png"));
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BorrowList window = new BorrowList();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	

	/**
	 * Create the application.
	 */
	public BorrowList() {
		initialize();
		addListener();
		queryBorrowList1();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100,550, 300);
		frame.setTitle("���ļ�¼");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"4.png");//����ͼ��
		frame.getContentPane().setLayout(null);
		
		label = new JLabel("\u501F\u9605\u4FE1\u606F");
		label.setBounds(245, 10, 54, 15);
		frame.getContentPane().add(label);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 40, 534, 131);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		label_1 = new JLabel("\u501F\u4E66\u8BC1\u53F7\uFF1A");
		label_1.setBounds(109, 184, 77, 15);
		frame.getContentPane().add(label_1);
		
		textField = new JTextField();
		textField.setBounds(196, 181, 103, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		button = new JButton("\u67E5\u627E");
		
		button.setBounds(378, 181, 93, 23);
		frame.getContentPane().add(button);
		
		titleLabel.setBounds(0, 0,550, 300);
		frame.getContentPane().add(titleLabel);
	}
	public void 	addListener() {
		
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {  //���ݽ���֤�Ų��ҽ�����Ϣ
				jsnumber=textField.getText();
				ArrayList<Borrow>borrow=borrowservice.borrowList(jsnumber);
				Iterator<Borrow>iterator=borrow.iterator();
				ArrayList<Reader>reader=readerservice.queryReader();
				Iterator<Reader>iterator_1=reader.iterator();
				int flag=0;
				int flag1=0;
				while(iterator.hasNext()) {
					Borrow m=new Borrow();
					m=iterator.next();
					if(m.getJsnumber().equals(jsnumber)) {
						flag=1;
						break;
					}
				}
				while(iterator_1.hasNext()) {
					Reader n=new Reader();
					n=iterator_1.next();
					if(n.getJsnumber().equals(jsnumber)) {
						flag1=1;
						break;
					}
				}
				if(flag==1) {
					find();
					queryBorrowList();
				}
				else if(flag==0&&flag1==1)JOptionPane.showMessageDialog(frame, "�ö���û�н��ļ�¼");
				else JOptionPane.showMessageDialog(frame, "�ö��߲�����");
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
		
	}
	public void find () {
		
		type="ѧ��";
		 jsnumber=textField.getText();
		int m=jsnumber.length();
		if(m==6) type="��ʦ";
		
	}
	public void queryBorrowList1(){
		//�������ͷ
		String[] thead = {"����֤��","��������","ͼ����","����","����ʱ��","�黹����"};
		//����adminService�Ĳ�ѯ����
		ArrayList<Borrow> dataList = null;
		//����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
		String[][] tbody = null;
		//����ѯ���Ľ��Ϊtable��ֵ
		TableModel dataModel = new DefaultTableModel(tbody,thead);
		table.setModel(dataModel);		
	}
	public void queryBorrowList(){
		//�������ͷ
		
		String[] thead = {"����֤��","��������","ͼ����","����","����ʱ��","�黹����"};
		//����adminService�Ĳ�ѯ����
		ArrayList<Borrow> dataList = borrowservice.borrowList(jsnumber);
		//����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
		String[][] tbody = listToArray(dataList);
		//����ѯ���Ľ��Ϊtable��ֵ
		TableModel dataModel = new DefaultTableModel(tbody,thead);
		table.setModel(dataModel);		
	}
	// ��������תΪ��ά����
		private String[][] listToArray(ArrayList<Borrow> list) {   //����ת��ΪString��ά����
			String[][] tbody = new String[list.size()][6];
			for (int i = 0; i < list.size(); i++) {
				Borrow n = list.get(i);
				Book m=bookservice.findBook(n.getBnumber());
						tbody[i][0] = n.getJsnumber();
						tbody[i][1] = type;
						tbody[i][2] = n.getBnumber();
						tbody[i][3] = m.getBname();
						tbody[i][4] = n.getBorrowdate()+"";
						tbody[i][5] = n.getReturndate()+"";
				}
				return tbody;
			}
}
