package view;


import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import Vo.Order;
import service.BookService;
import service.OrderService;
import tools.GUITools;
import javax.swing.JScrollPane;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Buy {	//��������-ͼ�鶩��

	JFrame frame;
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label;
	private JButton button;
	private JButton button_1;
	private OrderService orderservice=new OrderService();
	private BookService  bookservice=new BookService();
	private JScrollPane scrollPane;
	private JLabel titleLabel = new JLabel(new ImageIcon("9.jpg"));

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Buy window = new Buy();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Buy() {
		initialize();
		addListener();
		queryOrder();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 666, 401);
		frame.setTitle("����ͼ��");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"10.jpg");//����ͼ��
		frame.getContentPane().setLayout(null);
		
		label = new JLabel("\u5DF2\u8D2D\u4E70\u6E05\u5355");
		label.setBounds(276, 10, 83, 15);
		frame.getContentPane().add(label);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 37, 630, 178);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		textField = new JTextField();
		
		textField.setBounds(10, 262, 54, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(94, 262, 54, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(170, 262, 61, 21);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(260, 262, 58, 21);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(336, 262, 54, 21);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(413, 262, 54, 21);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		button = new JButton("\u8D2D\u4E70");
		
		button.setBounds(532, 261, 93, 23);
		frame.getContentPane().add(button);
		
		label_1 = new JLabel("\u56FE\u4E66\u7F16\u53F7");
		label_1.setBounds(20, 238, 54, 15);
		frame.getContentPane().add(label_1);
		
		label_2 = new JLabel("\u4E66\u540D");
		label_2.setBounds(94, 238, 54, 15);
		frame.getContentPane().add(label_2);
		
		label_3 = new JLabel("\u4F5C\u8005");
		label_3.setBounds(170, 237, 54, 15);
		frame.getContentPane().add(label_3);
		
		label_4 = new JLabel("\u51FA\u7248\u5355\u4F4D");
		label_4.setBounds(250, 237, 54, 15);
		frame.getContentPane().add(label_4);
		
		label_5 = new JLabel("\u5355\u4EF7");
		label_5.setBounds(336, 238, 54, 15);
		frame.getContentPane().add(label_5);
		
		label_6 = new JLabel("\u6570\u91CF");
		label_6.setBounds(413, 237, 54, 15);
		frame.getContentPane().add(label_6);
		
		textField_6 = new JTextField();
		textField_6.setBounds(10, 293, 54, 21);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		button_1 = new JButton("\u5220\u9664");
		
		button_1.setBounds(532, 294, 93, 23);
		frame.getContentPane().add(button_1);
		
		titleLabel.setBounds(0, 0, 800, 500);
		frame.getContentPane().add(titleLabel);
	}
	public void addListener() {
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {// ����
				if(panDuan()) {  //��ʽ�͸��ֲ���Ϊ��
					buy();
				}	
			}
		});
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {//����ͼ����ɾ��
				String bnumber=textField_6.getText();
				ArrayList<Order>order=orderservice.queryOrder();
				Iterator<Order>order1=order.iterator();
				int flag=0;
				while(order1.hasNext()) {
					Order m=new Order();
					m=order1.next();
					if(m.getTnumber().equals(bnumber)) {
						flag=1;
						break;
					}
				}
				if(flag==1)
				{
					del();
				}
				else {
					JOptionPane.showMessageDialog(frame, "����Ų�����");
					textField_6.setText("");
				}
			}
		});
		textField.addFocusListener(new FocusAdapter() {   //ͼ���ż���
			@Override
			public void focusLost(FocusEvent e) {
				String bnumber=textField.getText();
				ArrayList<Order>order=orderservice.queryOrder();
				Iterator<Order>order1=order.iterator();
				while(order1.hasNext()) {
					Order m=new Order();
					m=order1.next();
					if(m.getTnumber().equals(bnumber)) {
						JOptionPane.showMessageDialog(frame, "������Ѿ��ڶ��������");
						textField.setText("");
						break;
					}
				}
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
	}
	/*String tnumber, String tname, String author, String publish, Double price, Date dgdate,
	Integer dgquantity, String administer, String checkout*/
	public void buy() {
		String tnumber=textField.getText();
		String tname=textField_1.getText();
		String author=textField_2.getText();
		String publish=textField_3.getText();
		String price =textField_4.getText();
		String dgquantity=textField_5.getText();
		boolean succ=orderservice.addOrder(tnumber, tname, author, publish,Double.valueOf(price) , Integer.valueOf(dgquantity));
		 if(succ) {
			 JOptionPane.showMessageDialog(frame, "���ӳɹ�");
			 queryOrder();
			 textField.setText("");
			 textField_1.setText("");
			 textField_2.setText("");
			 textField_3.setText("");
			 textField_4.setText("");
			 textField_5.setText("");
		 }
		else JOptionPane.showMessageDialog(frame, "����ʧ��");
	}
	public void del() {
		String tnumber=textField_6.getText();
		boolean succ=orderservice.delOrder(tnumber);
		 if(succ) {
			 JOptionPane.showMessageDialog(frame, "ɾ���ɹ�");
			 queryOrder();
		         textField_6.setText("");
		 }
		 else 
			{
			 JOptionPane.showMessageDialog(frame, "ɾ��ʧ��");
			 textField_6.setText("");
		}
	}
	public boolean panDuan() {
		String tnumber=textField.getText();
		String tname=textField_1.getText();
		String author=textField_2.getText();
		String publish=textField_3.getText();
		String price =textField_4.getText();
		String dgquantity=textField_5.getText();
		boolean succ1=dgquantity.matches("[0-9]{1,6}");
		int m=dgquantity.length();
		if(tnumber.equals("")) {
			 JOptionPane.showMessageDialog(frame, "��Ų���Ϊ��");
			 return false;
			}else if(tname.equals("")) {
				 JOptionPane.showMessageDialog(frame, "��������Ϊ��");
				 return false;
			}else if(author.equals("")) {
				 JOptionPane.showMessageDialog(frame, "���߲���Ϊ��");
				 return false;
			}else if(publish.equals("")) {
				 JOptionPane.showMessageDialog(frame, "�����粻��Ϊ��");
				 return false;
			}else if(price.equals("")) {
				 JOptionPane.showMessageDialog(frame, "�۸���Ϊ��");
				 return false;
			}else if(dgquantity.equals("")) {
				 JOptionPane.showMessageDialog(frame, "��������Ϊ��");
				 return false;
			}else if(m>2) {
    			JOptionPane.showMessageDialog(frame, "�Ȿ�鹺������̫���ˣ�����������");
    			textField_5.setText("");
    			 return false;
    		}else if(succ1==false) {
        		JOptionPane.showMessageDialog(frame, "������͵Ŀɽ���������int����");
        		textField_5.setText("");
        	    return false;
    			} 
		try{
			Double.parseDouble(price);
			}catch(Exception e)
			{
				JOptionPane.showMessageDialog(frame, "�۸��ʽ���ԣ�����������");
				textField_4.setText("");
				 return false;
			}
	 return true;
	}
	public void queryOrder(){
		//�������ͷ
		String[] thead = {"ͼ����","����","����","���浥λ","����","����","��������","����Ա"};
		//����adminService�Ĳ�ѯ����
		ArrayList<Order> dataList = orderservice.queryOrder();
		//����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
		String[][] tbody = listToArray(dataList);
		//����ѯ���Ľ��Ϊtable��ֵ
		TableModel dataModel = new DefaultTableModel(tbody,thead);
		table.setModel(dataModel);		
	}
	// ��������תΪ��ά����
				private String[][] listToArray(ArrayList<Order> list) {   //����ת��ΪString��ά����
					String[][] tbody = new String[list.size()][9];
					for (int i = 0; i < list.size(); i++) {
						Order n = list.get(i);
						tbody[i][0] = n.getTnumber();
						tbody[i][1] = n.getTname();
						tbody[i][2] = n.getAuthor();
						tbody[i][3] = n.getPublish();
						tbody[i][4] = n.getPrice()+"";
						tbody[i][5] = n.getDgquantity()+"";
						tbody[i][6] = n.getDgdate()+"";
						tbody[i][7] = n.getAdminister();
					}
					return tbody;
				}
}
