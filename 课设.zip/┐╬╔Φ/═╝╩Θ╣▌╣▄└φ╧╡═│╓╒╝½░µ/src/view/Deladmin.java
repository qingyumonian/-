package view;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import Vo.Admin;
import service.AdminService;
import tools.GUITools;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Deladmin {   //ά��ϵͳ-ɾ������Ա

	 JFrame frame;
	private JTextField textField;
	private JTable table;
	private JLabel label;
	private JButton button_1;
	private JButton button;
	private JScrollPane scrollPane;
    private AdminService adminservice=new AdminService();
    private JLabel titleLabel = new JLabel(new ImageIcon("1.jpg"));
	/**
	 * Create the application.���췽��
	 */
	public Deladmin() {
		initialize();//���ڳ�ʼ��
		addListener();//������
		findAdmin();//ˢ�±���
	}
	/**
	 * Initialize the contents of the frame.���ڳ�ʼ��
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setTitle("ɾ������Ա");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"2.png");//����ͼ��
		frame.getContentPane().setLayout(null);
		
		label = new JLabel("\u7BA1\u7406\u5458\u540D\u79F0\uFF1A");
		label.setBounds(23, 23, 79, 15);
		frame.getContentPane().add(label);
		
		textField = new JTextField();
		
		textField.setBounds(135, 20, 79, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		button = new JButton("\u67E5\u8BE2");
		
		button.setBounds(286, 19, 93, 23);
		frame.getContentPane().add(button);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(23, 78, 360, 75);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		button_1 = new JButton("\u5220\u9664");
		
		button_1.setBounds(170, 200, 93, 23);
		frame.getContentPane().add(button_1);
		
		titleLabel.setBounds(0, 0, 450, 300);
		frame.getContentPane().add(titleLabel);
	}
	public void addListener() {
		
		button.addActionListener(new ActionListener() {  //��ѯ
			public void actionPerformed(ActionEvent e) {
				String administer=textField.getText();//��ȡ��������
		    	ArrayList<Admin> m=adminservice.queryAdmin();
				Iterator<Admin>iterator=m.iterator();
				int flag=0;
				while(iterator.hasNext()) {
					Admin n=new Admin();
					n=iterator.next();
					if(n.getAdminister().equals(administer)&&administer.equals("")==false)
					{
						flag=1;
						
						break;
					}
				}
				if(flag==0) {
					JOptionPane.showMessageDialog(frame, "���û�������");
				}else findAdmin();
			}
		});
		button_1.addActionListener(new ActionListener() {   //ɾ��
			public void actionPerformed(ActionEvent e) {
				del();
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
	}
		public void del() {
			String  administer=textField.getText();
			boolean succ=adminservice.delAdmin(administer);
			if(succ) {
				JOptionPane.showMessageDialog(frame, "ɾ���ɹ�");
				textField.setText("");
			}
				else JOptionPane.showMessageDialog(frame, "ɾ��ʧ��");
		}
		
	// ��ѯ����
	public void findAdmin() {          //ˢ�±������������
					// �������ͷ
					String  administer=textField.getText();
					String[] thead = { "�û���", "����"};
					// ����adminService�Ĳ�ѯ����
					Admin dataList = adminservice.findAdmin(administer);
					// ����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
					String[][] tbody = listToArray(dataList);
					// ����ѯ���Ľ��Ϊtable��ֵ
					TableModel dataModel = new DefaultTableModel(tbody, thead);
					table.setModel(dataModel);
				}
				// ��������תΪ��ά����
	private String[][] listToArray(Admin m) {   //����ת��ΪString��ά����
					String[][] tbody = new String[1][2];
					
						tbody[0][0] = m.getAdminister();
						tbody[0][1] = m.getPassword();
					return tbody;
	}
}
