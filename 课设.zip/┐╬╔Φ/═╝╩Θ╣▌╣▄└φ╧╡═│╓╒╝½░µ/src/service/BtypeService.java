package service;


import java.util.ArrayList;
import java.util.Iterator;
import Vo.Btype;
import dao.BtypeDao;

public class BtypeService {     //ͼ�����
    private BtypeDao btypedao=new BtypeDao();
	public BtypeService() {
		// TODO Auto-generated constructor stub
	}

	public ArrayList<Btype> queryBtype(){
		ArrayList <Btype> admin=btypedao.queryAllData();
		return admin;
	}
	public Btype findBtype1(String lnumber){
		Btype t=btypedao.findBtype1(lnumber);
    	return t;
    }
	//String lnumber, String lname, Integer kjday
	public boolean addBtype(String lnumber, String lname, Integer kjday) {
		ArrayList<Btype> m=queryBtype();
		Iterator<Btype>iterator=m.iterator();
		while (iterator.hasNext())
		{
			Btype n=new Btype(); 
	     	n=iterator.next();
		     if(n.getLnumber().equals(lnumber))
		     {
		    	 return false;
		     }
			
		}
		Btype thisbtype=new Btype(lnumber,lname,kjday);
		boolean addSuccess=btypedao.addBtype(thisbtype);
		if(addSuccess)
		return true;
		else return false;
	}
	
	public boolean updataBtype(String lnumber, String lname, Integer kjday) {
		ArrayList<Btype> m=queryBtype();
		Iterator<Btype>iterator=m.iterator();
		//System.out.println(lnumber);
		int flag=0;
		while (iterator.hasNext())
		{
			Btype n=new Btype(); 
	     	n=iterator.next();
		     if(n.getLnumber().equals(lnumber))
		     {
		    	 flag=1;
		    	break;
		     }
			
		}
		if(flag==1)
		{
			boolean updataSuccess=btypedao.updataBtype(lnumber, lname, kjday);
			if(updataSuccess)
			return true;
		}
	 return false;
	}
	public String findBtype(String lname){
		    	ArrayList<Btype> m=queryBtype();
		    	
				Iterator<Btype>iterator=m.iterator();
				String lnumber=null;
				while (iterator.hasNext())
				{
					Btype n=new Btype(); 
			     	n=iterator.next();
				     if(n.getLname().equals(lname))
				     {
				    	 lnumber=n.getLnumber();
				    	 break;
				     }
					
				}
		    	
		    	return lnumber;
		    }
	
	public String[] btypeName() {
		ArrayList<Btype> m=queryBtype();
		Iterator<Btype>iterator=m.iterator();
		String []name=new  String[m.size()];
		int i=0;
		while (iterator.hasNext())
		{
			
			Btype n=new Btype(); 
	     	n=iterator.next();
		    name[i++]=n.getLname();
	   }
		return name;
	}
}
