package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import Vo.Book;
import dbc.JDBCUtils;



/**
 *ͼ���Dao�� �� ɾ ��
 *
 */
public class BookDao {   

	public ArrayList<Book>queryAllData(){   //����ͼ�鼯��
		Connection conn=null;
		Statement stmt=null;
		ResultSet  rs=null;
		ArrayList <Book> shu=new ArrayList<Book>();
		try{
			conn=JDBCUtils.getConnection(1);
			stmt=conn.createStatement();
			String sql="select bnumber,bname,author,publish,price,amount,sjnumber,rkdate,lnumber from Book";
			rs=stmt.executeQuery(sql);
			while(rs.next()){
				Book book=new Book();
				book.setBnumber(rs.getString("bnumber"));
				book.setBname(rs.getString("bname"));
				book.setAuthor(rs.getString("author"));
				book.setPublish(rs.getString("publish"));
				book.setPrice(rs.getDouble("price"));
				book.setAmount(rs.getInt("amount"));
				book.setSjnumber(rs.getString("sjnumber"));
				book.setRkdate(rs.getDate("rkdate"));
				book.setLnumber(rs.getString("lnumber"));
				shu.add(book);
			}
			return shu;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return null;
	}
	
	public boolean addBook(Book m){     //ͼ����Ϣ������
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try{
			conn=JDBCUtils.getConnection(1);
			String sql="insert into Book(bnumber,bname,author,publish,price,amount,sjnumber,rkdate,lnumber)values(?,?,?,?,?,?,?,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, m.getBnumber());
			pstmt.setString(2, m.getBname());
			pstmt.setString(3, m.getAuthor());
			pstmt.setString(4, m.getPublish());
			pstmt.setDouble(5, m.getPrice());
			pstmt.setInt(6, m.getAmount());
			pstmt.setString(7, m.getSjnumber());
			pstmt.setDate(8, m.getRkdate());
			pstmt.setString(9, m.getLnumber());
			
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result =true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;

	}
	
	public boolean delBook(String bnumber){     //ͼ����Ϣɾ��
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result=false;
		try{
			conn=JDBCUtils.getConnection(1);
			String  sql="delete from Book where bnumber = ?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, bnumber);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
    public boolean updateBook(String bnumber,String bname,String author,String publish,Double price,Integer amount,String sjnumber,Date date,String lnumber){
        //ͼ����Ϣ����
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result=false;
		try{
			conn=JDBCUtils.getConnection(1);
			String  sql="update Book set bname=? ,author=? ,publish=? ,price=? ,amount=? ,sjnumber=? ,rkdate=? ,lnumber=? where bnumber=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, bname);
			pstmt.setString(2, author);
			pstmt.setString(3, publish);
			pstmt.setDouble(4, price);
			pstmt.setInt(5, amount);
			pstmt.setString(6, sjnumber);
			pstmt.setDate(7, date);
			pstmt.setString(8, lnumber);
			pstmt.setString(9, bnumber);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
    public boolean updataBookReduceShu(String bnumber) {//����ɹ����ͼ���һ
    	Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result=false;
		try{
			conn=JDBCUtils.getConnection(1);
			String  sql="update Book set amount=amount-1 where bnumber=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, bnumber);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
    public boolean updataBookAddShu(String bnumber) {//ͼ��黹�󣬿���ͼ���һ
    	Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result=false;
		try{
			conn=JDBCUtils.getConnection(1);
			String  sql="update Book set amount=amount+1 where bnumber=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, bnumber);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
    public Book findBook(String bnumber) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Book book = new Book();
		try{
			conn = JDBCUtils.getConnection(1);
			String sql = "select bnumber,bname,author,publish,price,amount,sjnumber,rkdate,lnumber from Book where bnumber=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bnumber);
			rs = pstmt.executeQuery();	
			if(rs == null)
				book = null;
			if(rs.next()){				
				book.setBnumber(rs.getString("bnumber"));
				book.setBname(rs.getString("bname"));
				book.setAuthor(rs.getString("author"));
				book.setPublish(rs.getString("publish"));
				book.setPrice(rs.getDouble("price"));
				book.setAmount(rs.getInt("amount"));
				book.setSjnumber(rs.getString("sjnumber"));
				book.setRkdate(rs.getDate("rkdate"));
				book.setLnumber(rs.getString("lnumber"));				
			}			
		}catch(Exception e ){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return book;		
	}
}
