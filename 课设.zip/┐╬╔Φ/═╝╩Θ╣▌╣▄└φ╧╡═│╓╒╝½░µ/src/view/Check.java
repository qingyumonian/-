package view;

import java.awt.Button;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import Vo.Order;
import service.OrderService;
import tools.GUITools;

import javax.swing.JScrollPane;

public class Check {	//��������-ͼ������

	JFrame frame;
	private JTable table;
	private JLabel label;
	private JLabel label_1;
	private JTextField textField;
	private JButton button;
	private JButton button_1;
	private OrderService orderservice=new OrderService();
	private JScrollPane scrollPane;
	private JLabel titleLabel = new JLabel(new ImageIcon("9.jpg"));
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Check window = new Check();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Check() {
		initialize();
		addListener();
		query();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 323);
		frame.getContentPane().setLayout(null);
		frame.setTitle("ͼ������");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"10.jpg");//����ͼ��
		
		label = new JLabel("\u672A\u9A8C\u6536\u6E05\u5355");
		label.setBounds(177, 10, 73, 15);
		frame.getContentPane().add(label);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 29, 414, 162);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		label_1 = new JLabel("\u56FE\u4E66\u7F16\u53F7:");
		label_1.setBounds(40, 215, 73, 15);
		frame.getContentPane().add(label_1);
		
		textField = new JTextField();
		textField.setBounds(131, 212, 66, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		button = new JButton("\u786E\u8BA4\u9A8C\u6536");
		
		button.setBounds(284, 211, 93, 23);
		frame.getContentPane().add(button);
		
		button_1 = new JButton("\u5168\u90E8\u9A8C\u6536");
		
		button_1.setBounds(284, 244, 93, 23);
		frame.getContentPane().add(button_1);
		
		titleLabel.setBounds(0, 0, 600, 500);
		frame.getContentPane().add(titleLabel);
	}
	public void addListener() {
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // ����ͼ���Ž���ȷ������
				String tnumber=textField.getText();
				ArrayList<Order>order=orderservice.queryfalseOrder();
				Iterator<Order>iterator=order.iterator();
				int flag=0;
				while(iterator.hasNext()) {
					Order m=new Order();
					m=iterator.next();
					if(m.getTnumber().equals(tnumber)) {
						flag=1;
						break;
					}
				}
				if(flag==1)
				check();
				else JOptionPane.showMessageDialog(frame, "������û��������");
			}
		});
		button_1.addActionListener(new ActionListener() {   //������ʾ��ͼ��ȫ������
			public void actionPerformed(ActionEvent arg0) {
				allCheck();
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
	}
	public void check() {
		String tnumber=textField.getText();
		boolean succ=orderservice.updataOrder(tnumber);
		 if(succ)
		 {
			 JOptionPane.showMessageDialog(frame, "���ճɹ�");
			 query();
			 textField.setText("");
		 }
		 else JOptionPane.showMessageDialog(frame, "����ʧ��");
	}
	public void allCheck() {
		ArrayList<Order> dataList = orderservice.queryfalseOrder();
		Iterator <Order>iterator=dataList.iterator();
		boolean succ=false;
		while(iterator.hasNext()) {
			Order m=new Order();
			m=iterator.next();
			 succ=orderservice.updataOrder(m.getTnumber());
		}
		 if(succ)
				JOptionPane.showMessageDialog(frame, "ȫ�����ճɹ�");
				else JOptionPane.showMessageDialog(frame, "��������ʧ��");
		
		
	}
	public void query(){
		//�������ͷ
		String[] thead = {"ͼ����","����","����","���浥λ"};
		//����adminService�Ĳ�ѯ����
		ArrayList<Order> dataList = orderservice.queryfalseOrder();
		//����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
		String[][] tbody = listToArray(dataList);
		//����ѯ���Ľ��Ϊtable��ֵ
		TableModel dataModel = new DefaultTableModel(tbody,thead);
		table.setModel(dataModel);		
	}
	// ��������תΪ��ά����
	private String[][] listToArray(ArrayList<Order> list) {   //����ת��ΪString��ά����
		String[][] tbody = new String[list.size()][5];
		for (int i = 0; i < list.size(); i++) {
			Order n = list.get(i);
			tbody[i][0] = n.getTnumber();
			tbody[i][1] = n.getTname();
			tbody[i][2] = n.getAuthor();
			tbody[i][3] = n.getPublish();
		}
		return tbody;
	}
}
