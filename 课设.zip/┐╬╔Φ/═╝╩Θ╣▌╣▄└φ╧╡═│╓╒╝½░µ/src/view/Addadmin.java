package view;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Vo.Admin;
import service.AdminService;
import tools.GUITools;

import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Addadmin {	   //ά��ϵͳ-���ӹ���Ա

	 JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JButton button;
	private AdminService adminservice=new AdminService();
	private JLabel titleLabel = new JLabel(new ImageIcon("1.jpg"));
	/**
	 * Create the application.
	 */
	public Addadmin() {
		initialize();
		addListener();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setTitle("���ӹ���Ա");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"2.png");//����ͼ��
		frame.getContentPane().setLayout(null);
		
		label = new JLabel("\u7BA1\u7406\u5458\u540D\u79F0\uFF1A");
		label.setBounds(50, 63, 93, 15);
		frame.getContentPane().add(label);
		
		textField = new JTextField();
		
		textField.setBounds(226, 60, 106, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		label_1 = new JLabel("\u5BC6      \u7801\uFF1A");
		label_1.setBounds(50, 121, 76, 15);
		frame.getContentPane().add(label_1);
		
		label_2 = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		label_2.setBounds(50, 172, 76, 15);
		frame.getContentPane().add(label_2);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(226, 118, 106, 21);
		frame.getContentPane().add(passwordField);
		
		passwordField_1 = new JPasswordField();
		
		passwordField_1.setBounds(226, 169, 106, 21);
		frame.getContentPane().add(passwordField_1);
		
		button = new JButton("\u521B\u5EFA");
		
		button.setBounds(143, 214, 93, 23);
		frame.getContentPane().add(button);
		
		titleLabel.setBounds(0, 0, 450, 300);
		frame.getContentPane().add(titleLabel);
	}
	public void addListener() {
		button.addActionListener(new ActionListener() {    //����
			public void actionPerformed(ActionEvent e) {
				addMin();
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
		textField.addFocusListener(new FocusAdapter() {  //�û�������
			@Override
			public void focusLost(FocusEvent arg0) {
				String administer=textField.getText();
		    	ArrayList<Admin> m=adminservice.queryAdmin();
				Iterator<Admin>iterator=m.iterator();
				while(iterator.hasNext()) {
					Admin n=new Admin();
					n=iterator.next();
					if(n.getAdminister().equals(administer)&&administer.equals("")==false)
					{
						JOptionPane.showMessageDialog(frame, "���û����Ѿ�����");
						break;
					}
				}
			}
		});
		
	}
	public  void addMin() {
		char mima[]=passwordField.getPassword();
		char mima1[]=passwordField_1.getPassword();
		String m=new String(mima);
		String n=new String (mima1);
		if(m.equals(n)==false)       //�ж��½����û������Ƿ���ȷ
		{
			JOptionPane.showMessageDialog(frame, "�û����������");
			passwordField.setText("");
			passwordField_1.setText("");
		}else
		{
			String name=textField.getText();
			if(name.equals(""))
				JOptionPane.showMessageDialog(frame, "�û���Ϊ�գ�����ʧ��");
			else {
				boolean succ =adminservice.addAdmin(name, m);
					if(succ) {
						JOptionPane.showMessageDialog(frame, "���ӳɹ�");
						textField.setText("");
						passwordField.setText("");
						passwordField_1.setText("");
					}
					else JOptionPane.showMessageDialog(frame, "����ʧ��");
			}
		}
	}
}
