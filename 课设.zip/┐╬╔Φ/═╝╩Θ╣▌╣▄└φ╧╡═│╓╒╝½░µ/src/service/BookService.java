package service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;  //ʱ��
import java.util.Iterator;
import Vo.Book;
import dao.BookDao;

public class BookService {
      private BookDao bookdao=new BookDao();
	public BookService() {}
	
    public ArrayList<Book>  queryBook(){//��ļ���
    	 ArrayList<Book> book=bookdao.queryAllData();
    	 return book;
    }
    public Book findBook(String bnumber){  //������
    	Book book=bookdao.findBook(bnumber);
    	return book;
  }
    public  boolean addBook(String bnumber,String bname, String author,String publish,String price,String amount,String sjnumber,String lnumber)
    {
		 Calendar canlendar =Calendar.getInstance();   //��ȡϵͳʱ������
 		 java.util.Date  date=canlendar.getTime();     //���util��ʱ��
 		java.sql.Date sqlDate=new java.sql.Date(date.getTime()); // ���ݿ��sql��date
		boolean succ=panDuan(bnumber);//ͼ�����Ƿ����
		if(succ==false) {
    	Book book=new Book(bnumber,bname,author,publish,Double.valueOf(price),Integer.valueOf(amount),sjnumber,sqlDate,lnumber);
    	  Boolean addSuccess=bookdao.addBook(book);
    	  if(addSuccess)
    	return true;
    	  else return false;
		}
		else {
			Book m=new Book();
			m=this.findBook(bnumber);
			Integer shu=m.getAmount()+Integer.valueOf(amount);
			Boolean updatasucc=this.updataBook(bnumber, bname, author, publish,price, shu.toString(), sjnumber, sqlDate, lnumber);
			if(updatasucc) {
				return true;
			}
			else return false;
		}
		
    }
    public boolean delBook(String bnumber) {
		ArrayList<Book> m=queryBook();
		Iterator<Book>iterator=m.iterator();
		int flag=0;
		while (iterator.hasNext())
		{
			Book n=new Book(); 
	     	n=iterator.next();
		     if(n.getBnumber().equals(bnumber))
		     {
		    	 
		    	 boolean delsuccess=bookdao.delBook(bnumber);
		    	 if(delsuccess)
		    		 flag=1; 
		    	break;
		     }
		}
		if(flag==1)
		return true;
		else return false;
	}
	public boolean updataBook(String bnumber,String bname, String author,String publish,String price,String amount,String sjnumber,Date date,String lnumber) {
		ArrayList<Book> m=queryBook();
		Iterator<Book>iterator=m.iterator();
		int flag=0;
		while (iterator.hasNext())
		{
			Book n=new Book(); 
	     	n=iterator.next();
		     if(n.getBnumber().equals(bnumber))
		     {
		    	 flag=1;
		    	 break;
		     }
			
		}
		if(flag==1)
		{
			boolean updataSuccess=bookdao.updateBook(bnumber, bname, author, publish, Double.valueOf(price),Integer.valueOf(amount), sjnumber, date, lnumber);
			if(updataSuccess)
			return true;
		}
		
		 return false;
	}
  public ArrayList<Book> findBookName(String bname){
	  ArrayList<Book> m=queryBook();
		Iterator<Book>iterator=m.iterator();
		ArrayList<Book>book=new ArrayList<Book>();
		while(iterator.hasNext()) {
			Book n=new Book();
			n=iterator.next();
			if(n.getBname().equals(bname)) {
				book.add(n);
			}
		}
	  return book;
	  
  }
	  public boolean panDuan(String bnumber){//ͼ�����Ƿ����
	    	ArrayList<Book> m=queryBook();
			Iterator<Book>iterator=m.iterator();
			int flag=0;
			while (iterator.hasNext())
			{
				Book n=new Book(); 
		     	n=iterator.next();
			     if(n.getBnumber().equals(bnumber))
			     {
			    	 flag=1;
			    	 break;
			     }
				
			}
	    	if(flag==0)
	    		return false;
	    	else return true;
	  }
}
