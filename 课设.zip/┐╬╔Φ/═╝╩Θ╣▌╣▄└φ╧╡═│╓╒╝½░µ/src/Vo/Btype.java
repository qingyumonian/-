package Vo;

public class Btype {     //ͼ�����

	      private String  lnumber;//�����
	      private String  lname;//�����
	      private Integer kjday;//�ɽ�����
	
	
	
	public Btype() {
		// TODO Auto-generated constructor stub
	}



	public Btype(String lnumber, String lname, Integer kjday) {
		super();
		this.lnumber = lnumber;
		this.lname = lname;
		this.kjday = kjday;
	}



	public String getLnumber() {
		return lnumber;
	}



	public void setLnumber(String lnumber) {
		this.lnumber = lnumber;
	}



	public String getLname() {
		return lname;
	}



	public void setLname(String lname) {
		this.lname = lname;
	}



	public Integer getKjday() {
		return kjday;
	}



	public void setKjday(Integer kjday) {
		this.kjday = kjday;
	}



	@Override
	public String toString() {
		return "Btype [lnumber=" + lnumber + ", lname=" + lname + ", kjday=" + kjday + "]";
	}

}
