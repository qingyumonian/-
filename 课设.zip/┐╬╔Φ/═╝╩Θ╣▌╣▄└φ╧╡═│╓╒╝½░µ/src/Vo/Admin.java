package Vo;

public class Admin {   //����Ա
        
	    private String  administer;
	    private String  passwords;
	     
	public Admin() {
		// TODO Auto-generated constructor stub
	}

	public Admin(String administer, String passwords) {
		super();
		this.administer = administer;
		this.passwords = passwords;
	}

	public String getAdminister() {
		return administer;
	}

	public void setAdminister(String administer) {
		this.administer = administer;
	}

	public String getPassword() {
		return passwords;
	}

	public void setPassword(String passwords) {
		this.passwords = passwords;
	}

	@Override
	public String toString() {
		return "Admin [administer=" + administer + ", password=" + passwords + "]";
	}

}
