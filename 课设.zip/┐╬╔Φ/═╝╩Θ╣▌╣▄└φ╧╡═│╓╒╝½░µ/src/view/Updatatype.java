package view;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import Vo.Btype;
import service.BtypeService;
import tools.GUITools;

public class Updatatype {//ͼ����Ϣ����-������-ͼ������޸�

	JFrame frame;
	private JTextField textField;
	private JTextField textField_2;
	private JTable table;
	private JScrollPane scrollPane;
	private JButton button;
	private JLabel label_1;
	private JTextField textField_1;
	private JButton button_1;
	private JLabel label;
	private JLabel label_2;
	private JLabel label_3;
	private JTextField textField_3;
	private BtypeService btypeservice=new BtypeService();
	private JLabel lblZ;
	private String lnumber=null;
	private JLabel titleLabel = new JLabel(new ImageIcon("6.jpg"));
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Updatatype window = new Updatatype();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Updatatype() {
		initialize();
		addListener();
		query();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 365);
		frame.getContentPane().setLayout(null);
		frame.setTitle("ͼ�������޸�");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"3.png");//����ͼ��
		textField = new JTextField();
		textField.setBounds(136, 234, 107, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(293, 234, 113, 21);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 80, 414, 109);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		button = new JButton("\u4FEE\u6539");
		
		button.setBounds(313, 278, 93, 23);
		frame.getContentPane().add(button);
		
		label_1 = new JLabel("\u7C7B\u522B\u540D\u79F0\uFF1A");
		label_1.setBounds(10, 29, 75, 15);
		frame.getContentPane().add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(136, 26, 107, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		button_1 = new JButton("\u67E5\u8BE2");
		
		button_1.setBounds(302, 25, 93, 23);
		frame.getContentPane().add(button_1);
		
		label = new JLabel("\u7C7B\u522B\u540D\u79F0");
		label.setBounds(158, 199, 54, 15);
		frame.getContentPane().add(label);
		
		label_2 = new JLabel("\u53EF\u501F\u5929\u6570");
		label_2.setBounds(293, 199, 54, 15);
		frame.getContentPane().add(label_2);
		
		label_3 = new JLabel("\u7C7B\u522B\u7F16\u53F7");
		label_3.setBounds(20, 199, 54, 15);
		frame.getContentPane().add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setBounds(19, 234, 93, 21);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		lblZ = new JLabel("\u6CE8\uFF1A\u7F16\u53F7\u4E0D\u80FD\u4FEE\u6539");
		lblZ.setBounds(20, 301, 107, 15);
		frame.getContentPane().add(lblZ);
		
		titleLabel.setBounds(0, 0, 600, 600);
		frame.getContentPane().add(titleLabel);
	}
     public void addListener() {
    	 button.addActionListener(new ActionListener() {   //�޸�
 			public void actionPerformed(ActionEvent e) {
 				if(panDuan()) {
 					updataBtype();
 				}
 				
 			}
 		});
    	 button_1.addActionListener(new ActionListener() {//��ѯ
 			public void actionPerformed(ActionEvent e) {
 				textField_3.setText("");
				textField.setText("");
				textField_2.setText("");
 				String lname =textField_1.getText();
 				ArrayList <Btype>m=btypeservice.queryBtype();
 				Iterator<Btype>n=m.iterator();
 				int flag=0;
 				while(n.hasNext()) {
 					Btype t=new Btype();
 					t=n.next();
 					if(t.getLname().equals(lname))
 					{
 						flag=1;
 						findBtype();
 						lnumber=textField_3.getText();
 						textField_3.requestFocus();
 						break;
 					}
 				}
 				if(flag==0) {
 					JOptionPane.showMessageDialog(frame, "����𲻴���");
						textField_1.setText("");
						textField_1.requestFocus();
 				}
 					
 			}
 		});
    	 frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
     }
     public void query() {          //ˢ�±������������
			// �������ͷ
			String[] thead = { "�����", "�������", "�ɽ�����"};
			// ����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
			String[][] tbody = null;
			// ����ѯ���Ľ��Ϊtable��ֵ
			TableModel dataModel = new DefaultTableModel(tbody, thead);
			table.setModel(dataModel);
		}
	public void findBtype() {          //ˢ�±������������
				String lnumber=btypeservice.findBtype(textField_1.getText());
				// �������ͷ
				String[] thead = { "�����", "�������", "�ɽ�����"};
				// ����adminService�Ĳ�ѯ����
				Btype dataList =btypeservice.findBtype1(lnumber);
				// ����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
				String[][] tbody = listToArray(dataList);
				// ����ѯ���Ľ��Ϊtable��ֵ
				TableModel dataModel = new DefaultTableModel(tbody, thead);
				table.setModel(dataModel);
				textField_3.setText(dataList.getLnumber());
				textField.setText(dataList.getLname());
				textField_2.setText(dataList.getKjday()+"");
				
			}
       public void updataBtype() {
        	
        	//String lnumber, String lname, Integer kjday
        	String lnumber=textField_3.getText();
        	String lname=textField.getText();
        	String kjday=textField_2.getText();
        	boolean succ1=kjday.matches("[0-9]{1,6}");//�������ʽ
        	if(succ1==false) {
        		JOptionPane.showMessageDialog(frame, "������͵Ŀɽ���������int����");
        	    textField_2.setText("");
        	}
        	else if(succ1==true){
        		int m=kjday.length();
        		if(m>3) {
        			JOptionPane.showMessageDialog(frame, "�Ȿ��Ŀɽ�����̫���ˣ�����������");
        			 textField_2.setText("");
        		}else {
        		boolean succ=btypeservice.updataBtype(lnumber, lname, Integer.valueOf(kjday));
	        	if(succ)
	        	{
	        		 JOptionPane.showMessageDialog(frame, "���³ɹ�");
	        		 findBtype();
					 textField.setText("");
					 textField_1.setText("");
					 textField_2.setText("");
					 textField_3.setText("");
	        	}else JOptionPane.showMessageDialog(frame, "����ʧ��");
        	}
        }	 
     }
			// ��������תΪ��ά����
	private String[][] listToArray(Btype m) {   //����ת��ΪString��ά����
				String[][] tbody = new String[1][3];
					tbody[0][0] = m.getLnumber();
					tbody[0][1] = m.getLname();
					tbody[0][2] = m.getKjday()+"";
				return tbody;
			}
	public boolean panDuan() {
		String lnumber=textField_3.getText();
		String lname=textField.getText();
    	String kjday=textField_2.getText();
    	if(lnumber.equals(this.lnumber)==false) {
    		JOptionPane.showMessageDialog(frame, "���ͱ�Ų���Ϊ��");
    		textField_3.setText(this.lnumber);
			return false;
    	}
    	if(lname.equals("")) {
    		JOptionPane.showMessageDialog(frame, "����������Ϊ��");
			return false;
    	}else if(kjday.equals("")) {
    		JOptionPane.showMessageDialog(frame, "�ɽ���������Ϊ��");
			return false;
    	}else return true;
	}
}
