package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import service.ReaderService;
import service.RtypeService;
import tools.GUITools;

import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ItemEvent;

public class Addreader {   //������Ϣ����--���Ӷ���

	JFrame frame;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_4;
	private JTextField textField_5;
	private JLabel name;
	private JLabel label;
	private JLabel sex;
	private JLabel yuanxi;
	private JLabel type;
	private JLabel ztype;
	private JLabel num;
	private JLabel phone;
	private JComboBox comboBox;
	private JButton button;
	private String stype="ѧ��";
	private String zjname="ѧ��֤";
	private String sex1="��";
	private RtypeService rtypeservice= new RtypeService();
	private ReaderService readerservice= new ReaderService();
	private JComboBox comboBox_2;
	private JComboBox comboBox_1;
	 private JLabel titleLabel = new JLabel(new ImageIcon("8.jpg"));
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Addreader window = new Addreader();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the application.
	 */
	public Addreader() {
		initialize();
		addListener();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 500);
		frame.getContentPane().setLayout(null);
		frame.setTitle("���Ӷ���");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"3.png");//����ͼ��
		label = new JLabel("���Ӷ���:");
		label.setBounds(171, 20, 73, 15);
		frame.getContentPane().add(label);
		
		name = new JLabel("��������:");
		name.setBounds(53, 72, 73, 15);
		frame.getContentPane().add(name);
		
		textField = new JTextField();
		textField.setBounds(251, 69, 106, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		sex = new JLabel("��    ��:");
		sex.setBounds(53, 111, 73, 15);
		frame.getContentPane().add(sex);
		
		yuanxi = new JLabel("Ժ     ϵ:");
		yuanxi.setBounds(53, 159, 73, 15);
		frame.getContentPane().add(yuanxi);
		
		textField_2 = new JTextField();
		
		textField_2.setBounds(251, 156, 106, 21);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);

		type = new JLabel("��������:");
		type.setBounds(53, 208, 73, 15);
		frame.getContentPane().add(type);
		String type []= {"ѧ��","��ʦ"};
		comboBox = new JComboBox<String>(type);
		comboBox.setMaximumRowCount(2);
		comboBox.setBounds(251, 205, 106, 21);
		frame.getContentPane().add(comboBox);
		
		ztype = new JLabel("֤������:");
		ztype.setBounds(53, 264, 73, 15);
		frame.getContentPane().add(ztype);
		
		num = new JLabel("֤������:");
		num.setBounds(53, 314, 73, 15);
		frame.getContentPane().add(num);
		
		textField_4 = new JTextField();
		textField_4.setBounds(251, 311, 106, 21);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		phone = new JLabel("��    ��:");
		phone.setBounds(53, 363, 73, 15);
		frame.getContentPane().add(phone);
		
		textField_5 = new JTextField();
		textField_5.setBounds(251, 360, 106, 21);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		button = new JButton("���Ӷ���");
		
		button.setBounds(139, 410, 93, 23);
		frame.getContentPane().add(button);
		String zjname []= {"ѧ��֤","��ʦ֤"};
		comboBox_1 = new JComboBox<String>(zjname);
		
		comboBox_1.setBounds(251, 261, 106, 21);
		frame.getContentPane().add(comboBox_1);
		String sex []= {"��","Ů"};
		comboBox_2 = new JComboBox<String>(sex);
		
		comboBox_2.setBounds(251, 108, 106, 21);
		frame.getContentPane().add(comboBox_2);
		
		titleLabel.setBounds(0, 0, 750, 300);
		frame.getContentPane().add(titleLabel);
	}
	public void addListener() {
       
		button.addActionListener(new ActionListener() {      //���Ӷ���
			public void actionPerformed(ActionEvent arg0) {
				if(panDuan()) {//ѧ����ʦ�ж�   �����绰Ժϵ ֤�����벻��Ϊ��
					add();
				}
			}
		});
		
		comboBox_2.addItemListener(new ItemListener() {   //�Ա����
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange()==ItemEvent.SELECTED)
				{
					sex1=(String)e.getItem();
				}
			}
		});
		comboBox_1.addItemListener(new ItemListener() {    //֤������
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange()==ItemEvent.SELECTED)
				{
					zjname=(String)e.getItem();
				}
			}
		});
		comboBox.addItemListener(new ItemListener() {  //ѧ�����ǽ�ʦ
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange()==ItemEvent.SELECTED)
				{
					stype=(String)e.getItem();
				}
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
		
	}
	public void add() {
		String name=textField.getText();
		String sex=this.sex1;
		String phone=textField_5.getText();
		String institute=textField_2.getText();
		String zjname=this.zjname;
		String zjnumber=textField_4.getText();
		String lxnumber=rtypeservice.findRtype(stype);
		int succ=readerservice.addReader( name, sex, phone, institute, zjname, zjnumber, lxnumber);
		 if(succ==1) {
			 JOptionPane.showMessageDialog(frame, "���ӳɹ�");
			 textField.setText(""); 
			 textField_2.setText("");
			 textField_4.setText("");
			 textField_5.setText("");
		 }
			else if(succ==0)JOptionPane.showMessageDialog(frame, "����ʧ��");
			else {
				JOptionPane.showMessageDialog(frame, "һ��֤������ֻ�ܴ���һ������");
				textField_4.setText("");
			}
	}
	public boolean panDuan() {  //ѧ����ʦ�ж�   �����绰Ժϵ ֤�����벻��Ϊ��
		String name=textField.getText();
		String phone=textField_5.getText();
		String institute=textField_2.getText();
		String rtype=this.stype;
		String zjname=this.zjname;
		String zjnumber=textField_4.getText();
		if(rtype.equals("ѧ��"))
		{
			if(zjname.equals("��ʦ֤"))
			{
				JOptionPane.showMessageDialog(frame, "ѧ��ֻ��ѧ��֤");
				return false;
			}else return true;
		}else if(rtype.equals("��ʦ")) {
			if(zjname.equals("ѧ��֤")) {
				JOptionPane.showMessageDialog(frame, "��ʦֻ�ý�ʦ֤");
				return false;
			}else return true;
		}
		else if(name.equals("")){
			JOptionPane.showMessageDialog(frame, "��������Ϊ��");	
			return false;
		}else if(phone.equals("")) {
			JOptionPane.showMessageDialog(frame, "�绰���벻��Ϊ��");
			return false;
		}else if(institute.equals("")) {
			JOptionPane.showMessageDialog(frame, "Ժϵ����Ϊ��");
			return false;
		}else if(zjnumber.equals("")) {
			JOptionPane.showMessageDialog(frame, "֤�����벻��Ϊ��");
			return false;
		}else return true;
	}
}
