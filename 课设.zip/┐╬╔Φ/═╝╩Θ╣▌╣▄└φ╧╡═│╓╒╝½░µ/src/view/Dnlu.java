package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Vo.Admin;
import service.AdminService;
import tools.GUITools;

import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Color;

public class Dnlu {     //����Ա��½
   // public static String administer=""; 
    public static String admin="";
	public JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	private JLabel label;
	private JLabel label_1;
	private JButton btnNewButton;
	private JLabel lblNewLabel;
	private JButton button_1;
	 private AdminService adminservice=new AdminService();
	 private JLabel label_2;
	 private JLabel titleLabel = new JLabel(new ImageIcon("19.jpg"));
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dnlu window = new Dnlu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public Dnlu() {
		initialize();
		addListener();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setTitle("��¼ϵͳ");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"28.png");//����ͼ��
		frame.getContentPane().setLayout(null);
		
		label = new JLabel("\u7528\u6237\u540D\uFF1A");
		label.setBounds(62, 42, 54, 15);  //�û���
		frame.getContentPane().add(label);
		
		label_1 = new JLabel("\u5BC6  \u7801\uFF1A");
		label_1.setBounds(62, 82, 54, 15);//����
		frame.getContentPane().add(label_1);
		
		textField = new JTextField();
		
		
		textField.setBounds(170, 42, 135, 21); //�����
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(170, 82, 135, 21);  // �����
		frame.getContentPane().add(passwordField);
		
		btnNewButton = new JButton("\u767B\u5F55");
		
		btnNewButton.setBounds(101, 132, 82, 23);
		frame.getContentPane().add(btnNewButton);
		
		button_1 = new JButton("\u4FEE\u6539\u5BC6\u7801");
		
		button_1.setBounds(222, 132, 93, 23);
		frame.getContentPane().add(button_1);
		
		label_2 = new JLabel("");
		label_2.setForeground(Color.RED);
		label_2.setBounds(325, 42, 119, 15);
		frame.getContentPane().add(label_2);
		
		titleLabel.setBounds(0, 0, 450, 300);
		frame.getContentPane().add(titleLabel);
	}
	public void addListener() {
		btnNewButton.addActionListener(new ActionListener() {//��¼
			public void actionPerformed(ActionEvent arg0) {
				if(panduan()) {
					 denglu();
				}
			    
			}
		});
		button_1.addActionListener(new ActionListener() {  //�޸�����
			public void actionPerformed(ActionEvent e) {
				if(panduan()) {
					updata();
				}
				
			}
		});
		textField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				panduan();
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
			   frame.dispose();
			            }
			  });
	}
	//String administer, String passwords
	public void denglu() {
		String administer=textField.getText();
		char mima[]=passwordField.getPassword();
		String mima1=new String(mima);
		Iterator<Admin> iterator = adminservice.queryAdmin().iterator();
		int flag=0;
		while(iterator.hasNext()){
			Admin m = new Admin();
			m=iterator.next();
			if(m.getAdminister().equals(administer)){
				flag=1;
				if(m.getPassword().equals(mima1))
				{
					frame.dispose();
					this.admin=m.getAdminister();
					Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
				}
				else{
					JOptionPane.showMessageDialog(frame, "�û����������");
				}
			}			
		}
		if(flag==0)JOptionPane.showMessageDialog(frame, "�û�������");
	}
	public void updata() {
		    String administer=textField.getText();
		    admin=administer;
		    frame.dispose();
			UpdataAdmin window = new UpdataAdmin();
			window.frame.setVisible(true);
		
	}
	public boolean panduan() {
		String administer=textField.getText();
		Iterator<Admin> iterator = adminservice.queryAdmin().iterator();
		int flag=0;
		while(iterator.hasNext()){
			Admin m = new Admin();
			m=iterator.next();
			label_2.setText("");  //��ʾ֮�� �ٴ����� ɾ����仰
			if(administer.equals(""))
			{
				label_2.setText("�û�������Ϊ��");
				flag=2;
				return false;
			}
			else if(m.getAdminister().equals(administer)){
				flag=1;
				break;
				}
		}
		
		if(flag==0) {
			JOptionPane.showMessageDialog(frame, "�û�������");
			textField.setText("");
			return false;
		}else return true;
	}
}
