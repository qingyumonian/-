package view;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import Vo.Reader;
import Vo.Rtype;
import service.ReaderService;
import service.RtypeService;
import tools.GUITools;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Updatareader {	//������Ϣ����-������Ϣ�޸���ɾ��

	JFrame frame;
	private JTextField textField;
	private JTable table;
	private JLabel label_1;
	private JLabel label;
	private JButton button;
	private JScrollPane scrollPane;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JButton button_1;
	private JLabel lblNewLabel;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel lblNewLabel_1;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;
	private JLabel label_8;
	private JButton button_2;
	private JLabel label_9;
	private JTextField textField_1;
	private ReaderService readerservice= new ReaderService(); 
	private RtypeService rtypeservice= new RtypeService(); 
	private String lxname=null;
	private String amount=null;
	private String jsnumber=null;
	private JLabel titleLabel = new JLabel(new ImageIcon("8.jpg"));
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Updatareader window = new Updatareader();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	

	/**
	 * Create the application.
	 */
	public Updatareader() {
		initialize();
		addListener();
		queryReader();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100,1100, 350);
		frame.getContentPane().setLayout(null);
		frame.setTitle("������Ϣ�޸�");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"3.png");//����ͼ��
		label = new JLabel("\u8BFB\u8005\u501F\u4E66\u8BC1\u53F7:");
		label.setBounds(27, 30, 96, 15);
		frame.getContentPane().add(label);
		
		textField = new JTextField();
		textField.setBounds(163, 27, 114, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		button = new JButton("\u67E5\u8BE2");
		
		button.setBounds(312, 26, 93, 23);
		frame.getContentPane().add(button);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(27, 67, 912, 89);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		label_1 = new JLabel("\u6CE8\uFF1A\u6CA1\u6709\u5728\u4FEE\u6539\u6846\u91CC\u8FDB\u884C\u4FEE\u6539\u7684\u4E3A\u4E4B\u524D\u7684\u503C");
		label_1.setBounds(26, 286, 290, 15);
		frame.getContentPane().add(label_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(128, 209, 66, 21);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(216, 209, 66, 21);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(309, 209, 66, 21);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(401, 209, 66, 21);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(491, 209, 54, 21);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(566, 209, 81, 21);
		frame.getContentPane().add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBounds(665, 209, 81, 21);
		frame.getContentPane().add(textField_8);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setBounds(756, 209, 72, 21);
		frame.getContentPane().add(textField_9);
		textField_9.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setBounds(856, 209, 54, 21);
		frame.getContentPane().add(textField_10);
		textField_10.setColumns(10);
		
		button_1 = new JButton("\u4FEE\u6539");
		
		button_1.setBounds(964, 208, 93, 23);
		frame.getContentPane().add(button_1);
		
		lblNewLabel = new JLabel("\u59D3\u540D");
		lblNewLabel.setBounds(128, 170, 54, 15);
		frame.getContentPane().add(lblNewLabel);
		
		label_2 = new JLabel("\u6027\u522B");
		label_2.setBounds(216, 170, 54, 15);
		frame.getContentPane().add(label_2);
		
		label_3 = new JLabel("\u9662\u7CFB");
		label_3.setBounds(307, 170, 54, 15);
		frame.getContentPane().add(label_3);
		
		lblNewLabel_1 = new JLabel("\u8BFB\u8005\u7C7B\u578B");
		lblNewLabel_1.setBounds(401, 170, 54, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		label_4 = new JLabel("\u8BC1\u4EF6\u7C7B\u578B");
		label_4.setBounds(491, 170, 54, 15);
		frame.getContentPane().add(label_4);
		
		label_5 = new JLabel("\u8BC1\u4EF6\u53F7\u7801");
		label_5.setBounds(581, 170, 54, 15);
		frame.getContentPane().add(label_5);
		
		label_6 = new JLabel("\u8054\u7CFB\u7535\u8BDD");
		label_6.setBounds(672, 166, 54, 15);
		frame.getContentPane().add(label_6);
		
		label_7 = new JLabel("\u529E\u8BC1\u65E5\u671F");
		label_7.setBounds(762, 166, 54, 15);
		frame.getContentPane().add(label_7);
		
		label_8 = new JLabel("\u6570\u91CF");
		label_8.setBounds(856, 166, 54, 15);
		frame.getContentPane().add(label_8);
		
		button_2 = new JButton("\u5220\u9664");
		
		button_2.setBounds(964, 251, 93, 23);
		frame.getContentPane().add(button_2);
		
		label_9 = new JLabel("\u501F\u4E66\u8BC1\u53F7");
		label_9.setBounds(37, 170, 54, 15);
		frame.getContentPane().add(label_9);
		
		textField_1 = new JTextField();
		textField_1.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				
			}
		});
		textField_1.setBounds(37, 209, 66, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		titleLabel.setBounds(0, 0, 1090, 300);
		frame.getContentPane().add(titleLabel);
	}
	public void addListener() {
		button.addActionListener(new ActionListener() {    //��ѯ
			public void actionPerformed(ActionEvent e) {
				String  jsnumber=textField.getText();
			      ArrayList<Reader>reader=readerservice.queryReader();
			      Iterator<Reader>iterator=reader.iterator();
			      int flag=0;
			      while(iterator.hasNext()) {
			    	  Reader m=new Reader();
			    	  m=iterator.next();
			    	  if(m.getJsnumber().equals(jsnumber)) {
			    		  flag=1;
			    		  break;
			    	  }
			      }
			      if(flag==0)
					JOptionPane.showMessageDialog(frame, "û���������");
			      else {
			    	  //System.out.println(jsnumber);
					findReader();
					tianJia();
			      }
			}
		});
		button_1.addActionListener(new ActionListener() {  //�޸�
			public void actionPerformed(ActionEvent e) {
				if(panDuan()) {
					updataReader();
				   findReader();
				}
			}
		});
		button_2.addActionListener(new ActionListener() {  //ɾ��
			public void actionPerformed(ActionEvent e) {
				delReader();
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
	}
	public void findReader() {
		String jsnumber=textField.getText();
		
		String[] thead = { "����֤��", "��    ��", "�Ա�", "Ժϵ", "��������","֤������","֤������","��ϵ�绰","��֤����","����������" };
		// ����adminService�Ĳ�ѯ����
		Reader dataList =readerservice.findReader(jsnumber) ;
		// ����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
		String[][] tbody = listToArray(dataList);
		// ����ѯ���Ľ��Ϊtable��ֵ
		TableModel dataModel = new DefaultTableModel(tbody, thead);
		table.setModel(dataModel);
	}
	public void updataReader() {
		String jsnumber=textField_1.getText();
		String name=textField_2.getText();
		String sex=textField_3.getText();
		String institute=textField_4.getText();
		String lxname=textField_5.getText();
		String zjname=textField_6.getText();
		String zjnumber=textField_7.getText();
		String phone=textField_8.getText();
		String bjdate=textField_9.getText();
		String lxnumber=rtypeservice.findRtype(lxname);
		//"����֤��", "��    ��", "�Ա�", "Ժϵ", "��������","֤������","֤������","��ϵ�绰","��֤����","����������"
		boolean succ=readerservice.updataReader(jsnumber, name, sex, phone, institute, zjname, zjnumber,Date.valueOf(bjdate), lxnumber);
		 if(succ) {
			 JOptionPane.showMessageDialog(frame, "���³ɹ�");
			 textField_1.setText("");
			 textField_2.setText("");
			 textField_3.setText("");
			 textField_4.setText("");
			 textField_5.setText("");
			 textField_6.setText("");
			 textField_7.setText("");
			 textField_8.setText("");
			 textField_9.setText("");
			 textField_10.setText("");
		 }
			else JOptionPane.showMessageDialog(frame, "����ʧ��");
		
	}
	public void delReader() {
		String jsnumber=textField.getText();
		int succ=readerservice.delReader(jsnumber);
		if(succ==1) {
			 JOptionPane.showMessageDialog(frame, "ɾ���ɹ�");
			 textField_1.setText("");
			 textField_2.setText("");
			 textField_3.setText("");
			 textField_4.setText("");
			 textField_5.setText("");
			 textField_6.setText("");
			 textField_7.setText("");
			 textField_8.setText("");
			 textField_9.setText("");
			 textField_10.setText("");
		}
			
		else  if(succ==0)JOptionPane.showMessageDialog(frame, "ɾ��ʧ��");
		else if(succ==2)JOptionPane.showMessageDialog(frame, "�ö����н����¼��ͼ�黹û�й黹");
	}
	  // ��ѯ����
		public void queryReader() {          //ˢ�±������������
			// �������ͷ
			String[] thead = { "����֤��", "��    ��", "�Ա�", "Ժϵ", "��������","֤������","֤������","��ϵ�绰","��֤����","����������" };
			String[][] tbody = null;
			// ����ѯ���Ľ��Ϊtable��ֵ
			TableModel dataModel = new DefaultTableModel(tbody, thead);
			table.setModel(dataModel);
		}

		// ��������תΪ��ά����
		private String[][] listToArray(Reader m) {   //����ת��ΪString��ά����
			String[][] tbody = new String[1][10];
			Rtype n=rtypeservice.findRtype1(m.getLxnumber());
				tbody[0][0] = m.getJsnumber();
				tbody[0][1] = m.getName();
				tbody[0][2] = m.getSex();
				tbody[0][3] = m.getInstitute();
				tbody[0][4] = n.getLxname();
				tbody[0][5] = m.getZjname();
				tbody[0][6] = m.getZjnumber();
				tbody[0][7] = m.getPhone();
				tbody[0][8] = m.getBjdate()+"";
				tbody[0][9] = n.getKjamount()+"";
			return tbody;
		}
		public void tianJia() {
			String jsnumber=textField.getText();
			Reader m =readerservice.findReader(jsnumber) ;
			Rtype n=rtypeservice.findRtype1(m.getLxnumber());
			lxname=n.getLxname();
			amount=n.getKjamount()+"";
			this.jsnumber=m.getJsnumber();
			textField_1.setText(m.getJsnumber());
			textField_2.setText(m.getName());
			textField_3.setText(m.getSex());
			textField_4.setText(m.getInstitute());
			textField_5.setText(n.getLxname());
			textField_6.setText(m.getZjname());
			textField_7.setText(m.getZjnumber());
			textField_8.setText(m.getPhone());
			textField_9.setText(m.getBjdate()+"");
			textField_10.setText(n.getKjamount()+"");
			textField_1.requestFocus();//���λ��
		}
		public boolean panDuan() {
			String jsnumber=textField_1.getText();
			String name=textField_2.getText();
			String sex=textField_3.getText();
			String institute=textField_4.getText();
			String lxname=textField_5.getText();
			String zjname=textField_6.getText();
			String zjnumber=textField_7.getText();
			String phone=textField_8.getText();
			String bjdate=textField_9.getText();
			String amount=textField_10.getText();
			if(this.jsnumber.equals(jsnumber)==false) {
				JOptionPane.showMessageDialog(frame, "����֤�Ų��ܸ���");
				textField_1.setText(this.jsnumber);
				return false;
			}
			else
				if(this.lxname.equals(lxname)==false) {
				JOptionPane.showMessageDialog(frame, "�������Ͳ��ܸ���");
				textField_5.setText(this.lxname);
				return false;
			}
				else if(this.amount.equals(amount)==false) {
				JOptionPane.showMessageDialog(frame, "���߿ɽ�ͼ���������ܸ���");
				textField_10.setText(this.amount);
				return false;
			}
				
				else if(name.equals("")){
				JOptionPane.showMessageDialog(frame, "��������Ϊ��");	
				return false;
			}else  if(sex.equals("")) {
				JOptionPane.showMessageDialog(frame, "�Ա���Ϊ��");
				return false;
			}
			else if(phone.equals("")) {
				JOptionPane.showMessageDialog(frame, "�绰���벻��Ϊ��");
				return false;
			}else if(institute.equals("")) {
				JOptionPane.showMessageDialog(frame, "Ժϵ����Ϊ��");
				return false;
			}else if(zjnumber.equals("")) {
				JOptionPane.showMessageDialog(frame, "֤�����벻��Ϊ��");
				return false;
			}
			else if(bjdate.equals("")) {
				JOptionPane.showMessageDialog(frame, "��֤���ڲ���Ϊ��");
				return false;
			}else if(lxname.equals("ѧ��"))
			{
				if(zjname.equals("ѧ��֤")==false)
				{
					JOptionPane.showMessageDialog(frame, "ѧ��ֻ��ѧ��֤");
					textField_6.setText("ѧ��֤");
					return false;
				}else return true;
			}
				else if(lxname.equals("��ʦ")) {
				if(zjname.equals("��ʦ֤")==false) {
					JOptionPane.showMessageDialog(frame, "��ʦֻ�ý�ʦ֤");
					textField_6.setText("��ʦ֤");
					return false;
				}else return true;
			}
			else	return true;
		}
}
