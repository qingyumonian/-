package Vo;

public class Rtype {   //�������

	    private String   lxnumber;   //��𻻺�
	    private String 	 lxname;    //�������
	    private Integer  kjamount;  //�ɽ�����
	
	public Rtype() {
		// TODO Auto-generated constructor stub
	}
	public Rtype(String lxnumber, String lxname, Integer kjamount) {
		super();
		this.lxnumber = lxnumber;
		this.lxname = lxname;
		this.kjamount = kjamount;
	}
	public String getLxnumber() {
		return lxnumber;
	}


	public void setLxnumber(String lxnumber) {
		this.lxnumber = lxnumber;
	}


	public String getLxname() {
		return lxname;
	}


	public void setLxname(String lxname) {
		this.lxname = lxname;
	}


	public Integer getKjamount() {
		return kjamount;
	}


	public void setKjamount(Integer kjamount) {
		this.kjamount = kjamount;
	}


	@Override
	public String toString() {
		return "Rtype [lxnumber=" + lxnumber + ", lxname=" + lxname + ", kjamount=" + kjamount + "]";
	}

}
