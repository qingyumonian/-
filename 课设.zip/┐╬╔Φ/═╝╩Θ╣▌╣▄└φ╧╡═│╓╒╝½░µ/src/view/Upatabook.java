package view;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import Vo.Book;
import Vo.Btype;
import service.BookService;
import service.BtypeService;
import tools.GUITools;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Upatabook { //ͼ����Ϣ����-��Ϣ����-ͼ����Ϣ�޸�

	 JFrame frame;
	private JTextField textField;
	private JTable table;
	private JLabel label_1;
	private JLabel label;
	private JButton button;
	private JScrollPane scrollPane;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_9;
	private JTextField textField_10;
	private JButton button_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;
	private JLabel label_9;
	private JLabel label_10;
	private JTextField textField_1;
	private BookService bookservice=new BookService();
	private BtypeService btypeservice=new BtypeService();
	private JLabel label_8;
	private String bnum=null;
	private JLabel titleLabel = new JLabel(new ImageIcon("6.jpg"));
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Upatabook window = new Upatabook();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public Upatabook() {
		initialize();
		addListener();
		 queryBook() ;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100,942, 350);
		frame.getContentPane().setLayout(null);
		frame.setTitle("ͼ���޸�");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"3.png");//����ͼ��
		label = new JLabel("\u4E66\u53F7");
		label.setBounds(31, 30, 96, 15);
		frame.getContentPane().add(label);
		
		textField = new JTextField();
		textField.setBounds(163, 27, 114, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		button = new JButton("\u67E5\u8BE2");
		
		button.setBounds(312, 26, 93, 23);
		frame.getContentPane().add(button);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(25, 55, 856, 89);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		label_1 = new JLabel("\u6CE8\uFF1A\u6CA1\u6709\u5728\u4FEE\u6539\u6846\u91CC\u8FDB\u884C\u4FEE\u6539\u7684\u4E3A\u4E4B\u524D\u7684\u503C,\u56FE\u4E66\u7F16\u53F7\u4E0D\u53EF\u4EE5\u4FEE\u6539");
		label_1.setBounds(27, 273, 378, 15);
		frame.getContentPane().add(label_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(120, 195, 66, 21);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(212, 195, 66, 21);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(312, 195, 66, 21);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(412, 195, 66, 21);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(499, 195, 84, 21);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(604, 195, 66, 21);
		frame.getContentPane().add(textField_7);
		textField_7.setColumns(10);
		
		textField_9 = new JTextField();
		
		textField_9.setBounds(697, 195, 66, 21);
		frame.getContentPane().add(textField_9);
		textField_9.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setBounds(799, 195, 66, 21);
		frame.getContentPane().add(textField_10);
		textField_10.setColumns(10);
		
		button_1 = new JButton("\u4FEE\u6539");
		
		button_1.setBounds(461, 250, 93, 23);
		frame.getContentPane().add(button_1);
		
		label_2 = new JLabel("\u4E66\u540D");
		label_2.setBounds(120, 158, 54, 15);
		frame.getContentPane().add(label_2);
		
		label_3 = new JLabel("\u4F5C\u8005");
		label_3.setBounds(212, 158, 54, 15);
		frame.getContentPane().add(label_3);
		
		label_4 = new JLabel("\u51FA\u7248\u793E");
		label_4.setBounds(312, 158, 54, 15);
		frame.getContentPane().add(label_4);
		
		label_5 = new JLabel("\u5355\u4EF7");
		label_5.setBounds(413, 158, 54, 15);
		frame.getContentPane().add(label_5);
		
		label_6 = new JLabel("\u5165\u5E93\u65E5\u671F");
		label_6.setBounds(511, 158, 54, 15);
		frame.getContentPane().add(label_6);
		
		label_7 = new JLabel("\u6570\u91CF");
		label_7.setBounds(604, 158, 54, 15);
		frame.getContentPane().add(label_7);
		
		label_9 = new JLabel("\u56FE\u4E66\u7C7B\u522B");
		label_9.setBounds(697, 158, 54, 15);
		frame.getContentPane().add(label_9);
		
		label_10 = new JLabel("\u4E66\u67B6\u7F16\u53F7");
		label_10.setBounds(799, 158, 54, 15);
		frame.getContentPane().add(label_10);
		
		label_8 = new JLabel("\u4E66\u53F7");
		label_8.setBounds(35, 158, 54, 15);
		frame.getContentPane().add(label_8);
		
		textField_1 = new JTextField();
		
		textField_1.setBounds(25, 195, 66, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		titleLabel.setBounds(0, 0, 1000, 500);
		frame.getContentPane().add(titleLabel);
	}
	public void addListener() {
	
		textField_9.addFocusListener(new FocusAdapter() {   //ͼ����������
			@Override
			public void focusLost(FocusEvent arg0) {
				String lname=textField_9.getText();
				ArrayList <Btype>m=btypeservice.queryBtype();
 				Iterator<Btype>n=m.iterator();
 				int flag=0;
 				while(n.hasNext()) {
 					Btype t=new Btype();
 					t=n.next();
 					if(t.getLname().equals(lname))
 					{
 						flag=1;
 						break;
 					}
 				}
 				if(flag==0) {
 					JOptionPane.showMessageDialog(frame, "����𲻴���");
						textField_9.setText("");
 				}
			}
		});
		button.addActionListener(new ActionListener() {    //��ѯ
			public void actionPerformed(ActionEvent e) {
				String bnumber=textField.getText();
				ArrayList<Book>book=bookservice.queryBook();
				Iterator<Book>m=book.iterator();
				int flag=0;
				//System.out.println(bnumber);
				while(m.hasNext()) {
					Book n=new Book();
					n=m.next();
					if(n.getBnumber().equals(bnumber))
					{
						flag=1;
						findBook();
				        zengTian();
				        textField_1.requestFocus();
				        bnum=textField_1.getText();
				        break;
					}
				}
				if(flag==0)
					JOptionPane.showMessageDialog(frame, "��û���Ȿ��");
			}
		});
		button_1.addActionListener(new ActionListener() {//�޸�
			public void actionPerformed(ActionEvent e) {
				if(panDuan()) {
					updataBook();
				}
				
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
	}
	// ��ѯ����
		public void queryBook() {          //ˢ�±������������
			// �������ͷ
			String[] thead = { "���", "����", "����", "������ ", "����","�������","����","ͼ�����","��ܱ��"};
			// ����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
			String[][] tbody = null;
			// ����ѯ���Ľ��Ϊtable��ֵ
			TableModel dataModel = new DefaultTableModel(tbody, thead);
			table.setModel(dataModel);
		}
		// ��ѯ����
				public void findBook() {          //ˢ�±������������
					// �������ͷ
					String bnumber=textField.getText();
					String[] thead = { "���", "����", "����", "������ ", "����","�������","����","ͼ�����","��ܱ��"};
					// ����adminService�Ĳ�ѯ����
					Book dataList =bookservice.findBook(bnumber) ;
					// ����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
					String[][] tbody = listToArray(dataList);
					// ����ѯ���Ľ��Ϊtable��ֵ
					TableModel dataModel = new DefaultTableModel(tbody, thead);
					table.setModel(dataModel);
				}
		public void updataBook() {
			/*String bnumber, String bname, String author, String publish, Double price, Integer amount,
			String sjnumber, Date rkdate, String lnumber*/
			String bnumber=textField_1.getText();
			String bname=textField_2.getText();
			String author=textField_3.getText();
			String publish=textField_4.getText();
			String price=textField_5.getText();
			String rkdate=textField_6.getText();
			String amount=textField_7.getText();
			String lname=textField_9.getText();
			String lnumber=btypeservice.findBtype(lname);
			String sjnumber=textField_10.getText();
			boolean succ=bookservice.updataBook(bnumber, bname, author, publish, price, amount, sjnumber, Date.valueOf(rkdate), lnumber);
			 if(succ) {
				 JOptionPane.showMessageDialog(frame, "���³ɹ�");
				 findBook();
				 this.bnum="";
				 textField.setText("");
				 textField_1.setText("");
				 textField_2.setText("");
				 textField_3.setText("");
				 textField_4.setText("");
				 textField_5.setText("");
				 textField_6.setText("");
				 textField_7.setText("");
				 textField_9.setText("");
				 textField_10.setText("");
			 }
				else JOptionPane.showMessageDialog(frame, "����ʧ��");
			
		}		
	 private String[][] listToArray(Book m) {   //����ת��ΪString��ά����
					String[][] tbody = new String[1][9];
						Btype n=btypeservice.findBtype1(m.getLnumber());
						tbody[0][0] = m.getBnumber();
						tbody[0][1] = m.getBname();
						tbody[0][2] = m.getAuthor();
						tbody[0][3] = m.getPublish();
						tbody[0][4] = m.getPrice() + "";
						tbody[0][5] = m.getRkdate()+"";
						tbody[0][6] = m.getAmount()+"";
						tbody[0][7] = n.getLname();
						tbody[0][8] = m.getSjnumber();
					
					return tbody;
				  }
	public void zengTian() {
		//"���", "����", "����", "������ ", "����","�������","����","�ɽ�����","ͼ�����","��ܱ��"
		String bnumber=textField.getText();
		Book m =bookservice.findBook(bnumber);
		Btype n=btypeservice.findBtype1(m.getLnumber());
		textField_1.setText(m.getBnumber());
		textField_2.setText(m.getBname());
		textField_3.setText(m.getAuthor());
		textField_4.setText(m.getPublish());
		textField_5.setText(m.getPrice()+"");
		textField_6.setText(m.getRkdate()+"");
		textField_7.setText(m.getAmount()+"");
		textField_9.setText(n.getLname());
		textField_10.setText(m.getSjnumber());
	}
	public boolean panDuan() {
		String bname=textField_2.getText();
		String author=textField_3.getText();
		String publish=textField_4.getText();
		String price=textField_5.getText();
		String rkdate=textField_6.getText();
		String amount=textField_7.getText();
		String lname=textField_9.getText();
		String sjnumber=textField_10.getText();
		String bnumber=textField_1.getText();
		try{
			Double.parseDouble(price);
			}catch(Exception e)
			{
				JOptionPane.showMessageDialog(frame, "�۸��ʽ���ԣ�����������");
				textField_5.setText("");
				 return false;
			}
		if(bnumber.equals(bnum)==false) {
			JOptionPane.showMessageDialog(frame, "��Ų����޸�");
			textField_1.setText(bnum);
			return false;
		}
		else if(bname.equals("")) {
			JOptionPane.showMessageDialog(frame, "��������Ϊ��");
			return false;
		}else if(author.equals("")) {
			JOptionPane.showMessageDialog(frame, "���߲���Ϊ��");
			return false;
		}if(publish.equals("")) {
			JOptionPane.showMessageDialog(frame, "�����粻��Ϊ��");
			return false;
		}if(price.equals("")) {
			JOptionPane.showMessageDialog(frame, "�۸���Ϊ��");
			return false;
		}if(rkdate.equals("")) {
			JOptionPane.showMessageDialog(frame, "������ڲ���Ϊ��");
			return false;
		}if(amount.equals("")) {
			JOptionPane.showMessageDialog(frame, "��������Ϊ��");
			return false;
		}if(lname.equals("")) {
			JOptionPane.showMessageDialog(frame, "�������Ʋ���Ϊ��");
			return false;
		}if(sjnumber.equals("")) {
			JOptionPane.showMessageDialog(frame, "��ܱ�Ų���Ϊ��");
			return false;
		}else return true;
	}
}
