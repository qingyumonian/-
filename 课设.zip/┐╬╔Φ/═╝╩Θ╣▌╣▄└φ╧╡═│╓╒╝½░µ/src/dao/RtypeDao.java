package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import Vo.Rtype;
import dbc.JDBCUtils;

public class RtypeDao {

	public RtypeDao() {
		// TODO Auto-generated constructor stub
	}
public ArrayList<Rtype>  queryAllData(){   //���ض������ļ���
		
		Connection conn=null;
		Statement  st=null;
		ResultSet rs=null;
		ArrayList <Rtype> user=new ArrayList<Rtype>();
		try{
			conn=JDBCUtils.getConnection(1);
			st=conn.createStatement();
			String sql="select lxnumber,lxname,kjamount from Rtype";
			rs=st.executeQuery(sql);
			while(rs.next())
			{
				Rtype m=new Rtype();
				m.setLxnumber(rs.getString("lxnumber"));
				m.setLxname(rs.getString("lxname"));
				m.setKjamount(rs.getInt("kjamount"));
				user.add(m);
			}
			return user;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return null;
		
	}
	public boolean   addRtype(Rtype m){//����Ա������
		Connection conn=null;
		PreparedStatement  pstmt=null;
		boolean  result=false;
		try{
			conn=JDBCUtils.getConnection(1);
			String sql="insert into Rtype (lxnumber,lxname,kjamount) values (?,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, m.getLxnumber());
			pstmt.setString(2, m.getLxname());
			pstmt.setInt(3, m.getKjamount());
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	public  boolean  delRtype(String  lxnumber){      //����Ա��ɾ��
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try{
			conn=JDBCUtils.getConnection(1);
			String sql="delete from Rtype where lxnumber=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,lxnumber);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
	public Rtype findRtype1(String lxnumber) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Rtype m=new Rtype();
		try{
			conn = JDBCUtils.getConnection(1);
			String sql = "select lxnumber,lxname,kjamount from Rtype where lxnumber=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, lxnumber);
			rs = pstmt.executeQuery();	
			if(rs == null)
				m = null;
			if(rs.next()){				
				m.setLxnumber(rs.getString("lxnumber"));
				m.setLxname(rs.getString("lxname"));
				m.setKjamount(rs.getInt("kjamount"));
			}			
		}catch(Exception e ){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return m;		
	}
}
