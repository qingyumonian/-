package Vo;

import java.sql.Date;

public class Reader {        //����
       
	private  String jsnumber;    //����֤��
	private  String name;
	private  String sex;
	private  String phone;
	private  String institute;//Ժϵ
	private  String zjname;//֤����
	private  String zjnumber;
	private  Date   bjdate;  //��֤����
	private String lxnumber;//�������ͱ��

	public Reader() {
		// TODO Auto-generated constructor stub
	}

	public Reader(String jsnumber, String name, String sex, String phone, String institute, String zjname,
			String zjnumber, Date bjdate, String lxnumber) {
		super();
		this.jsnumber = jsnumber;
		this.name = name;
		this.sex = sex;
		this.phone = phone;
		this.institute = institute;
		this.zjname = zjname;
		this.zjnumber = zjnumber;
		this.bjdate = bjdate;
		this.lxnumber = lxnumber;
	}

	public String getJsnumber() {
		return jsnumber;
	}

	public void setJsnumber(String jsnumber) {
		this.jsnumber = jsnumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getInstitute() {
		return institute;
	}

	public void setInstitute(String institute) {
		this.institute = institute;
	}

	public String getZjname() {
		return zjname;
	}

	public void setZjname(String zjname) {
		this.zjname = zjname;
	}

	public String getZjnumber() {
		return zjnumber;
	}

	public void setZjnumber(String zjnumber) {
		this.zjnumber = zjnumber;
	}

	public Date getBjdate() {
		return bjdate;
	}

	public void setBjdate(Date bjdate) {
		this.bjdate = bjdate;
	}

	public String getLxnumber() {
		return lxnumber;
	}

	public void setLxnumber(String lxnumber) {
		this.lxnumber = lxnumber;
	}

	@Override
	public String toString() {
		return "Reader [jsnumber=" + jsnumber + ", name=" + name + ", sex=" + sex + ", phone=" + phone + ", institute="
				+ institute + ", zjname=" + zjname + ", zjnumber=" + zjnumber + ", bjdate=" + bjdate + ", lxnumber="
				+ lxnumber + "]";
	}
   
}
