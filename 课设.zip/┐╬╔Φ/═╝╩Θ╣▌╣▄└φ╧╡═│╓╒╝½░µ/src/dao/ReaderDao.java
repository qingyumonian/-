package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import Vo.Reader;
import dbc.JDBCUtils;

/**
 * 
 * ����Dao��� �� ɾ  ��
 *
 */
public class ReaderDao {
	
	public ArrayList<Reader> queryAllData(){
		Connection conn=null;
		Statement  stmt=null;
		ResultSet rs=null;
		ArrayList<Reader> reader=new ArrayList<Reader>();
		try {
			conn=JDBCUtils.getConnection(1);
			stmt=conn.createStatement();
			String sql="select jsnumber,name,sex,phone,institute,zjname,zjnumber,bjdate,lxnumber from Reader ";
			rs=stmt.executeQuery(sql);
			while(rs.next()) {
				Reader m=new Reader();
				m.setJsnumber(rs.getString("jsnumber"));
				m.setName(rs.getString("name"));
				m.setSex(rs.getString("sex"));
				m.setPhone(rs.getString("phone"));
				m.setInstitute(rs.getString("institute"));
				m.setZjname(rs.getString("zjname"));
				m.setZjnumber(rs.getString("zjnumber"));
				m.setBjdate(rs.getDate("bjdate"));
				m.setLxnumber(rs.getString("lxnumber"));
				reader.add(m);
			}
/*String jsnumber, String name, String sex, String phone, String institute, String zjname,
			String zjnumber, Date bjdate, String lxnumber*/
		return reader;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return null;
	}
	
	public boolean addReader(Reader m) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try {
			conn=JDBCUtils.getConnection(1);
			String sql="insert into Reader (jsnumber,name,sex,phone,institute,zjname,zjnumber,bjdate,lxnumber) values(?,?,?,?,?,?,?,?,?)";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, m.getJsnumber());
			pstmt.setString(2, m.getName());
			pstmt.setString(3, m.getSex());
			pstmt.setString(4, m.getPhone());
			pstmt.setString(5, m.getInstitute());
			pstmt.setString(6, m.getZjname());
			pstmt.setString(7, m.getZjnumber());
			pstmt.setDate(8, m.getBjdate());
			pstmt.setString(9, m.getLxnumber());
			if(pstmt.executeUpdate()>0)
			{
				result=true;
			}
			/*String jsnumber, String name, String sex, String phone, String institute, String zjname,
			String zjnumber, Date bjdate, String lxnumber*/
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
    public boolean delReader(String jsnumber) {
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try{
			conn=JDBCUtils.getConnection(1);
			String  sql="delete from Reader where jsnumber = ?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, jsnumber);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
	}
    public boolean updataReader(String jsnumber, String name, String sex, String phone, String institute, String zjname,
			String zjnumber, Date bjdate, String lxnumber) {
    	Connection conn=null;
		PreparedStatement pstmt=null;
		boolean result =false;
		try{
			conn=JDBCUtils.getConnection(1);
			String  sql="update Reader set name=?,sex=?,phone=?,institute=?,zjname=?,zjnumber=?,bjdate= ?,lxnumber= ? where jsnumber= ?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, sex);
			pstmt.setString(3, phone);
			pstmt.setString(4, institute);
			pstmt.setString(5, zjname);
			pstmt.setString(6, zjnumber);
			pstmt.setDate(7, bjdate);
			pstmt.setString(8, lxnumber);
			pstmt.setString(9, jsnumber);
			int num=pstmt.executeUpdate();
			if(num>0)
			{
				result=true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return result;
    }
    public Reader findReader(String jsnumber) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Reader m = new Reader();
		try{
			conn = JDBCUtils.getConnection(1);
			String sql = "select jsnumber,name,sex,phone,institute,zjname,zjnumber,bjdate,lxnumber from Reader where jsnumber=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, jsnumber);
			rs = pstmt.executeQuery();	
			if(rs == null)
				m = null;
			if(rs.next()){				
				m.setJsnumber(rs.getString("jsnumber"));
				m.setName(rs.getString("name"));
				m.setSex(rs.getString("sex"));
				m.setPhone(rs.getString("phone"));
				m.setInstitute(rs.getString("institute"));
				m.setZjname(rs.getString("zjname"));
				m.setZjnumber(rs.getString("zjnumber"));
				m.setBjdate(rs.getDate("bjdate"));
				m.setLxnumber(rs.getString("lxnumber"));		
			}			
		}catch(Exception e ){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn);
		}
		return m;		
	}
}
