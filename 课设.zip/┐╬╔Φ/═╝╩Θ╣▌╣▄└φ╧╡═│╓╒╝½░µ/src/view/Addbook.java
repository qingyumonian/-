package view;



import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import Vo.Order;
import service.BookService;
import service.BtypeService;
import service.OrderService;
import tools.GUITools;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JComboBox;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class Addbook { // ͼ����Ϣ����-��Ϣ����-ͼ����Ϣ����

	 JFrame frame;
	private JTextField textField;
	private JLabel label_3;
	private JTextField textField_3;
	private JLabel lblNewLabel;
	private JTable table;
	private JScrollPane scrollPane;
	private JButton button_1;
	private JLabel label;
	private JLabel label_2;
	private JComboBox comboBox;
	private OrderService orderservice=new OrderService();
	private BookService bookservice=new BookService();
	private BtypeService btypeservice=new BtypeService();
	private String btype="������";
	 private JLabel titleLabel = new JLabel(new ImageIcon("6.jpg"));
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Addbook window = new Addbook();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	

	/**
	 * Create the application.
	 */
	public Addbook() {
		initialize();
		addListener();
		queryBook();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 980, 500);
		frame.setTitle("ͼ����Ϣ����");    //���ڱ�����
		GUITools.center(frame);      //������Ļ����
		frame.setResizable(false);   //�����С�̶�
		GUITools.setTitleImage(frame,"3.png");//����ͼ��
		frame.getContentPane().setLayout(null);
		
		label = new JLabel("\u4E66\u53F7\uFF1A");
		label.setBounds(10, 34, 54, 15);
		frame.getContentPane().add(label);
		
		textField = new JTextField();
		textField.setBounds(45, 31, 81, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		label_2 = new JLabel("\u56FE\u4E66\u7C7B\u578B\uFF1A");
		label_2.setBounds(180, 34, 66, 15);
		frame.getContentPane().add(label_2);
		
		label_3 = new JLabel("\u4E66\u67B6\u7F16\u53F7\uFF1A");
		label_3.setBounds(429, 34, 66, 15);
		frame.getContentPane().add(label_3);
		
		textField_3 = new JTextField();
	
		textField_3.setBounds(531, 31, 81, 21);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		lblNewLabel = new JLabel("\u53EF\u6DFB\u52A0\u56FE\u4E66");
		lblNewLabel.setBounds(355, 102, 74, 15);
		frame.getContentPane().add(lblNewLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 127, 912, 221);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		button_1 = new JButton("\u5165\u5E93");
		
		button_1.setBounds(770, 30, 93, 23);
		frame.getContentPane().add(button_1);
		
		String btype[]=btypeservice.btypeName();
		comboBox = new JComboBox(btype);
		comboBox.setMaximumRowCount(6);
		comboBox.setBounds(278, 31, 87, 21);
		frame.getContentPane().add(comboBox);
		
		titleLabel.setBounds(0, 0, 1000, 600);
		frame.getContentPane().add(titleLabel);
	}
	public void addListener() {
		
		button_1.addActionListener(new ActionListener() {   //����ͼ��
			public void actionPerformed(ActionEvent arg0) {
				if(panDuan()) {
					tianJia();
				}
			}
		});
		
		comboBox.addItemListener(new ItemListener() {   //��������
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange()==ItemEvent.SELECTED)
				{
					btype=(String)e.getItem();
				}
			}
		});
		textField_3.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				String bnumber=textField.getText();
				ArrayList<Order>order=orderservice.querytrueOrder();//�����Ѿ����ն�������
				Iterator<Order>m=order.iterator();
				int flag=0;
				while(m.hasNext()) {
					Order n=new Order();
					n=m.next();
					if(n.getTnumber().equals(bnumber)&&bnumber.equals("")==false)
					{
						flag=1;
					}	
				}
				if(flag==0)
				{
					JOptionPane.showMessageDialog(frame, "��û���Ȿ��");
					textField.setText("");
				}
			}
		});
		frame.addWindowListener(new WindowAdapter(){     //������Ͻǡ��رմ��ںͺ�̨��Դ
			   public void windowClosing(WindowEvent e) {
				   frame.dispose();
				   Mainmenu window = new Mainmenu();
					window.frame.setVisible(true);
			            }
			  });
	}
	
	public void tianJia() {
		String bnumber=textField.getText();
		String lname=btype;
		String sjnumber=textField_3.getText();
		ArrayList <Order> order=orderservice.queryOrder();
		Iterator <Order>iterator=order.iterator();
		while(iterator.hasNext()) {
			Order m=new Order();
			m=iterator.next();
			if(m.getTnumber().equals(bnumber)) {
			String	lnumber=btypeservice.findBtype(lname);   //ͼ�������������ͱ��
				boolean succ=bookservice.addBook(bnumber, m.getTname(), m.getAuthor(),m.getPublish(),m.getPrice().toString(), m.getDgquantity().toString(), sjnumber, lnumber);
				if(succ) {
					 JOptionPane.showMessageDialog(frame, "���ӳɹ�");
					 orderservice.delOrder(bnumber);
					 queryBook();
					 textField.setText("");
					 textField_3.setText("");
				 }
					else JOptionPane.showMessageDialog(frame, "����ʧ��");
				break;
			}
		}
	}
	public boolean panDuan() {
		String bnumber=textField.getText();
		String lnumber=btype;
		String sjnumber=textField_3.getText();
		if(bnumber.equals("")) {
			JOptionPane.showMessageDialog(frame, "��Ų���Ϊ��");
			return false;
		}
		else if(lnumber.equals("")) {
			JOptionPane.showMessageDialog(frame, "���Ͳ���Ϊ��");
			return false;
		}
		else if(sjnumber.equals("")) {
			JOptionPane.showMessageDialog(frame, "��ܱ�Ų���Ϊ��");
			return false;
		}
		else return true;
	}
	// ��ѯ����
	public void queryBook() {          //ˢ�±������������
					// �������ͷ
					String[] thead = { "���", "����", "����", "������ ", "����","��������","����","����Ա","�Ƿ�����" };
					// ����adminService�Ĳ�ѯ����
					ArrayList<Order> dataList =orderservice.querytrueOrder() ;
					// ����ѯ���ļ���תΪ���飬����ΪJTable��ֵ
					String[][] tbody = listToArray(dataList);
					// ����ѯ���Ľ��Ϊtable��ֵ
					TableModel dataModel = new DefaultTableModel(tbody, thead);
					table.setModel(dataModel);
				}
	private String[][] listToArray(ArrayList<Order> list) {   //����ת��ΪString��ά����
			String[][] tbody = new String[list.size()][10];
			for (int i = 0; i < list.size(); i++) {
				Order m = list.get(i);
				tbody[i][0] = m.getTnumber();
				tbody[i][1] = m.getTname();
				tbody[i][2] = m.getAuthor();
				tbody[i][3] = m.getPublish();
				tbody[i][4] = m.getPrice() + "";
				tbody[i][5] = m.getDgdate()+"";
				tbody[i][6] = m.getDgquantity()+"";
				tbody[i][7] = m.getAdminister();
				tbody[i][8] = m.getCheckout();
			}
			return tbody;
		  }
}
